# NEXA PE-02 — A1 COMPLETE EVIDENCE CLOSURE
## SEARCH SCOPE AND GAPS RECORD

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Date:** 2026-11-10

---

## 1. EXAMINED SEARCH SCOPES

The following directories, packages, and modules were exhaustively inspected:

1. **Identity Domain & Engine:**
   - `internal/domain/identity.go`
   - `internal/engine/identity/subject.go`
   - `internal/engine/identity/lineage.go`
   - `internal/engine/identity/active_key.go`
   - `internal/engine/identity/delegation.go`
   - `internal/engine/identity/verifier.go`
   - `pkg/nexa/domain/identity.go`
   - `pkg/nexa/identity.go`
2. **Ownership Domain & Engine:**
   - `internal/domain/ownership.go`
   - `internal/engine/ownership/cert.go`
   - `internal/engine/ownership/delegation.go`
   - `internal/engine/ownership/history.go`
   - `internal/engine/ownership/transfer.go`
   - `internal/engine/ownership/verifier.go`
   - `pkg/nexa/ownership.go`
3. **Federation & Registry Identity:**
   - `internal/domain/federation.go`
   - `internal/domain/registry_identity.go`
   - `internal/engine/federation/evaluator.go`
   - `pkg/nexa/federation.go`
4. **Service & Repository Layer:**
   - `internal/service/service.go`
   - `internal/service/ownership_service.go`
   - `internal/service/licensing_service.go`
   - `internal/repository/ownership_repository.go`
   - `internal/repository/license_event_repo.go`
5. **Client Applications:**
   - `apps/player-desktop/`
   - `apps/player-mobile/`
   - `apps/studio-desktop/`
   - `apps/verify-desktop/`
   - `apps/marketplace-backend/`
6. **Test Suites:**
   - `tests/identity/`
   - `tests/audit/sprint14/`
   - `internal/engine/ownership/`
   - `internal/engine/federation/`

---

## 2. EXACT SEARCH TERMS, SYMBOLS & COMMANDS

| Search Target | Command / Query | Scope | Results |
| :--- | :--- | :--- | :--- |
| Explicit Album Signing Scope | `grep -rnw "ALBUM_MEMBERSHIP_SIGNING" .` | Entire repository | **0 matches** |
| Album Origin / Authority | `grep -rni "album_origin" .` | `internal/`, `pkg/`, `apps/` | **0 matches** |
| Album Ownership Certificate | `grep -rni "album.*ownership" .` | `internal/`, `pkg/` | **0 matches** |
| Revocation Assertion | `grep -rni "RevocationAssertion" .` | `internal/`, `pkg/` | **0 matches** |
| Dual-Horizon Timestamps | `grep -rn "revoked_at" .` | `internal/`, `apps/` | Audit log metadata only (`service.go:L306`, `licensing.go:L37`) |
| Recorded-At Timestamps | `grep -rn "recorded_at" .` | `internal/`, `apps/` | `OwnershipEvent` struct (`ownership.go:L108`, `counter.go:L30`) |
| Subject ID Prefix | `grep -rn "urn:nexa:id:" .` | `internal/`, `tests/` | Defined in `subject.go:L10` and verified in tests |
| Delegation Allowlist | `grep -rn "IsValidDelegationScope" .` | `internal/` | Defined in `domain/ownership.go:L28-L42` (closed Sprint 11 allowlist) |
| Identity Engine Callers | `grep -rn "NewIdentityVerifier" .` | `apps/` | **0 matches in client apps** (only in `pkg/nexa/identity.go` and unit tests) |

---

## 3. UNEXAMINED SCOPES & ACCESS LIMITATIONS

- **Zero Unexamined In-Repo Scopes:** All Go packages, TypeScript/JavaScript client applications, DDL schemas, and migrations within `whisnu/nexa` were fully accessible and inspected.
- **External Network Registries:** Network queries to external third-party production registries were neither performed nor required; unit test mock fixtures and offline repository code were evaluated.

---

## 4. DETAILED GAP ANALYSIS & TECHNICAL RATIONALE

### Gap 1: Group A — Absence of Pinned Trust-Anchor Architecture in Identity Engine
- **Technical Fact:** `IdentityAssertion` contains `GenesisRootKey` and `SubjectID`, and `ExecutePipeline` verifies that `SubjectID == DeriveSubjectID(GenesisRootKey)`.
- **Reason for PARTIAL:** While the mathematical binding between key and Subject ID is verified, the verifier does not check whether `GenesisRootKey` is trusted by the client or registered in a local trust store. It acts as an identity integrity verifier rather than an absolute trust verifier.
- **Impact on A1:** For A1 Complete Evidence Closure, the verifier must define how an offline client decides to trust the Genesis Root Key (e.g. Creator identity registered in local cache or trusted issuer policy).

### Gap 2: Group B — Individual Creator Subject Lacks Key Lineage / Rotation Primitives
- **Technical Fact:** `RootRecoveryAssertion` and `ActiveKeyAuthorizationAssertion` exist and have full test coverage, but they are designed for Organization subjects.
- **Reason for PARTIAL:** An Individual Creator subject in `tests/identity/` has only a Genesis Root Key and cannot rotate keys or execute a 2-step recovery under the current engine.
- **Impact on A1:** If an Album is published by an Individual Creator, signing must use the Genesis Key directly unless a separate Individual Key Rotation schema is authorized.

### Gap 3: Group C — Ownership Evidence is Strictly Bound to Scalar Asset IDs
- **Technical Fact:** `OwnershipCertificate` and `CanonicalGenesisPayload` only take `AssetID string`.
- **Reason for NOT FOUND (Album-wide):** No structure exists to assert ownership or publishing authority over a set of assets or an `album_id`.
- **Impact on A1:** Existing Sprint 11 ownership code cannot be used "as-is" for Album-wide authority without creating a new schema or adapter.

### Gap 4: Group D — Registry Authority Engine is Exclusively Online
- **Technical Fact:** `Evaluator.Evaluate` issues live HTTP requests to `/v1/identity` and `/v1/certificates`. If offline (`len(cfg.Registries) == 0` or network failure), it returns `UNKNOWN` / `INCOMPLETE`.
- **Reason for PARTIAL:** `RegistryIdentity` has a valid JCS signature, but there is no mechanism to bundle or serialize a static Registry Attestation offline.
- **Impact on A1:** Offline verification of an album cannot rely on `Evaluator.Evaluate`.

### Gap 5: Group E — Absence of Standalone Signed Revocation Proofs & Dual-Horizon Logic
- **Technical Fact:** `IdentityVerifier.ExecutePipeline` relies on an ambient boolean flag `isRevoked`.
- **Reason for PARTIAL:** There is no signed `RevocationAssertion` payload that can be passed to the verifier, nor does the verifier compare `revoked_at` with `recorded_at`.
- **Impact on A1:** Dual-Horizon Time Rule cannot be executed without implementing the missing assertion carrier and verifier logic.

### Gap 6: Group F — Absence of `ALBUM_MEMBERSHIP_SIGNING` Scope and `album_id` Binding
- **Technical Fact:** `DelegationAssertion` only accepts generic strings in `DelegatedScope []string` and has no `album_id` field.
- **Reason for NOT FOUND:** The scope `ALBUM_MEMBERSHIP_SIGNING` does not exist in any domain model or allowlist.
- **Impact on A1:** Tier-2 delegation cannot be performed using existing code without introducing the capability token and scoping mechanism.

---

## 5. BOUNDS OF FACTUAL CONCLUSIONS

1. The findings in this report describe the exact state of `whisnu/nexa` at commit `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`.
2. A status of `NOT FOUND` indicates absence within the examined repository scope; it does not constitute a design proposal or an implementation proposal.
3. No architectural decisions (such as creating new schemas or choosing between wrapping and embedding) were made during this investigation.
