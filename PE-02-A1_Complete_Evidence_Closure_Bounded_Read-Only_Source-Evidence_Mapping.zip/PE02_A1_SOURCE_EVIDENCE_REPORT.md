# NEXA PE-02 — A1 COMPLETE EVIDENCE CLOSURE
## BOUNDED READ-ONLY SOURCE-EVIDENCE MAPPING REPORT

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Exact Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Working Tree:** Clean (untracked documentation files only: `docs/roadmaps/Nexa_Development_Roadmap_v4_8.md`, `docs/whitepapers/Nexa_White_Paper_v5_6.md`)
- **Inspection Date:** 2026-11-10
- **Role Boundary:** Nexa Programmer (Read-Only Investigation; Zero Code/Schema/Config Changes)
- **Applicable Plan Sections:** §16.16.4A and §16.16.4B clause 10

---

## 1. EXECUTIVE SUMMARY & EVIDENCE MATRIX (GROUPS A–F)

| Workstream | Area | Status | Evidence IDs | Gap Utama |
| :--- | :--- | :--- | :--- | :--- |
| **A** | Genesis Root Certificate / Creator Identity Credential | `PARTIAL` | `EVID-A01`, `EVID-A02` | `IdentityAssertion` exists with JCS Ed25519; no pinned root trust anchor certificate or external trust anchor pinning store in `ExecutePipeline`. |
| **B** | Key Lineage / Root Recovery / Active Key Sequencing | `PARTIAL` | `EVID-B01`, `EVID-B02`, `EVID-B03` | Organization 2-step recovery & monotonic Level-1 active key sequence fully implemented and tested; Individual Creator lacks separate key rotation/lineage mechanism. |
| **C** | Album-wide Ownership Evidence / Publisher-Origin Authority | `PARTIAL` | `EVID-C01`, `EVID-C02` | `OwnershipCertificate` and transfer lineage are strictly scalar per `asset_id`; zero data structures exist for Album-wide ownership, compilation rights, or publisher-origin authority. |
| **D** | Registry Authority / Federated Trust Proof | `PARTIAL` | `EVID-D01`, `EVID-D02` | `RegistryIdentity` with JCS Ed25519 signature exists; `Evaluator.Evaluate` is strictly online dynamic HTTP; zero offline self-contained cryptographic Registry proof structures exist. |
| **E** | Revocation Proof / Status Snapshot | `PARTIAL` | `EVID-E01`, `EVID-E02` | `isRevoked` bool flag and `RegistryKeyRevocationList` exist; no standalone `RevocationAssertion` or Dual-Horizon `revoked_at` vs `recorded_at` verification logic exists in verifiers. |
| **F** | Tier-2 Membership Authority / Album Signer Delegation | `PARTIAL` | `EVID-F01`, `EVID-F02` | 3-level generic `DelegationAssertion` exists; explicit scope `ALBUM_MEMBERSHIP_SIGNING` is `NOT FOUND` (0 matches), no `album_id` binding field exists, and verifier wiring to Album Manifest is absent. |

### Factual Summary
1. **Available in Source:** High-integrity cryptographic building blocks are present in Go engine: RFC 8785 JCS canonicalization, Ed25519 signing/verifying, deterministic Subject ID derivation (`urn:nexa:id:` + hex(sha256(GenesisRootKey))), 2-step root recovery with pre-image digest, monotonic sequence validation for Level-1 active keys, 3-level scoped delegation, and dynamic multi-registry federated conflict evaluation.
2. **Partially Available:** Identity Assertion verifies Subject-to-Key binding, but assumes Genesis Root Key as ambient input rather than validating against a pinned trust anchor store. Revocation is represented via online flags and key revocation lists, but lacks standalone signed revocation assertion proofs and Dual-Horizon time evaluation.
3. **Not Found in Examined Scope:** Album-wide ownership evidence, publisher-origin authority across multiple assets, offline self-contained Registry proof attestations, explicit capability token `ALBUM_MEMBERSHIP_SIGNING`, and `album_id` scoping inside delegations.
4. **Questions for AA:** Detailed in Section 10 regarding whether native `IdentityAssertion` and `DelegationAssertion` should be embedded directly or adapted into a dedicated PE-02 envelope, and how Album-wide authority designation should be formally structured.

---

## 2. EVIDENCE RECORDS (GROUPS A–F)

### Group A: Genesis Root Certificate / Creator Genesis Identity Credential

#### Evidence Record: `EVID-A01`
- **Workstream:** A
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/identity.go`
- **Line Range:** lines 51–78
- **Symbol:** `IdentityAssertion`, `OrganizationSubject`, `SubjectType`
- **Technical Finding:** Defines the canonical identity payload carrying GenesisRootKey, CurrentRootKey, ActivePublicKey, SubjectID, and TriState RecoveryKeyDigest. Serialized as JSON with JCS RFC 8785 canonicalization.
- **Verification Call Chain:** `IdentityVerifier.ExecutePipeline` (`internal/engine/identity/verifier.go:L23`) → JCS canonicalization (`crypto.CanonicalizeJCS`) → Ed25519 verification (`ed25519.Verify`).
- **Test Evidence:** `tests/identity/verifier_test.go:TestVerificationPipelineVerified` (PASS).
- **Limitation:** The credential is an assertion by the subject; it does not carry an issuer chain terminating at an external pre-pinned root trust anchor.

#### Evidence Record: `EVID-A02`
- **Workstream:** A
- **Status:** `PRESENT`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/engine/identity/subject.go`
- **Line Range:** lines 10–57
- **Symbol:** `DeriveSubjectID`, `VerifySubjectIDContinuity`, `FormatSubjectIDURN`, `ParseSubjectIDURN`
- **Technical Finding:** Deterministically binds raw 32-byte Ed25519 Genesis Public Key to Subject ID URN using formula `urn:nexa:id:` + lowercase hex of SHA-256. Enforces immutable continuity.
- **Verification Call Chain:** Direct helper function called by identity constructors and verification tests.
- **Test Evidence:** `tests/identity/subject_id_test.go:TestDeriveSubjectID`, `TestVerifySubjectIDContinuity` (PASS).
- **Limitation:** None for Subject ID derivation.

---

### Group B: Organization and Individual Creator Key-Lineage Evidence

#### Evidence Record: `EVID-B01`
- **Workstream:** B
- **Status:** `PRESENT`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/identity.go`, `internal/engine/identity/lineage.go`
- **Line Range:** `domain/identity.go:L81-L96`, `lineage.go:L15-L92`
- **Symbol:** `RootRecoveryAssertion`, `Verify2StepRootRecovery`
- **Technical Finding:** Implements the 2-step root recovery protocol: Step 1 verifies SHA-256 digest of RecoveryPublicKey against `genesis_recovery_key_digest`; Step 2 verifies Ed25519 signature over JCS canonical payload. Prohibits self-recovery to identical key.
- **Verification Call Chain:** `IdentityVerifier.ExecutePipeline` → `ResolveRootAuthorityAt` → `Verify2StepRootRecovery` → `crypto.CanonicalizeJCS` → `ed25519.Verify`.
- **Test Evidence:** `tests/identity/recovery_test.go:TestVerify2StepRootRecovery` (PASS), `tests/audit/sprint14/recovery_audit_test.go:TestAudit2StepRecoveryProtocol` (PASS).
- **Limitation:** Applies to Organization subjects that have committed a non-null recovery key digest at genesis.

#### Evidence Record: `EVID-B02`
- **Workstream:** B
- **Status:** `PRESENT`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/engine/identity/lineage.go`
- **Line Range:** lines 95–153
- **Symbol:** `ResolveRootAuthorityAt`
- **Technical Finding:** Resolves root authority at arbitrary timestamp `targetTimestamp`. Filters assertions with `EffectiveAt <= targetTimestamp`, detects competing branches for the same compromised root (`ErrCodeLineageBranchingConflict`), and traverses predecessor-successor key continuity.
- **Verification Call Chain:** Called by `IdentityVerifier.ExecutePipeline` (Step 2) and `VerifyActiveKeyAssertion`.
- **Test Evidence:** `tests/identity/lineage_test.go:TestUnboundedRecoveryLineageDepth`, `tests/audit/sprint14/lineage_audit_test.go:TestAuditLineageBranchingConflict` (PASS).
- **Limitation:** None for Organization root resolution.

#### Evidence Record: `EVID-B03`
- **Workstream:** B
- **Status:** `PRESENT`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/identity.go`, `internal/engine/identity/active_key.go`
- **Line Range:** `domain/identity.go:L99-L114`, `active_key.go:L14-L154`
- **Symbol:** `ActiveKeyAuthorizationAssertion`, `VerifyActiveKeyAssertion`, `ResolveActiveSigningAuthorityAt`
- **Technical Finding:** Enforces Level-1 active signing key authorization. Validates signature against `RootAuthorityAt(assertion.EffectiveAt)`. Enforces strict monotonic sequence (`SequenceNumber == 1` initially, then `pred.SequenceNumber + 1`), verifies `PreviousActiveKey` matches predecessor, and detects competing sequence conflicts (`ErrCodeActiveKeyConflict`).
- **Verification Call Chain:** `IdentityVerifier.ExecutePipeline` (Step 3) → `ResolveActiveSigningAuthorityAt` → `VerifyActiveKeyAssertion`.
- **Test Evidence:** `tests/identity/active_key_test.go:TestActiveKeyAuthorizationSequenceRules` (PASS), `tests/audit/sprint14/active_key_audit_test.go:TestAuditActiveKeyAuthorizationSequenceRules` (PASS).
- **Limitation:** Individual Creator subjects currently do not have an active key sequencing or rotation structure distinct from the Genesis key.

---

### Group C: Album-wide Ownership Evidence / Publisher-Origin Authority

#### Evidence Record: `EVID-C01`
- **Workstream:** C
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/ownership.go`, `internal/engine/ownership/cert.go`
- **Line Range:** `domain/ownership.go:L53-L68`, `cert.go:L14-L99`
- **Symbol:** `OwnershipCertificate`, `CanonicalGenesisPayload`, `CreateGenesisCertificate`
- **Technical Finding:** Defines dual-signed Genesis Ownership Certificate (`CreatorSignature` + `IssuerSignature`) over JCS canonical payload containing scalar `AssetID`, `CreatorPublicKey`, `EffectiveAt`, `IssuedAt`, `IssuerID`, `PreviousCertRef`, `SubjectID`, and `UnderlyingCertID`.
- **Verification Call Chain:** `internal/engine/ownership/verifier.go:VerifyOwnershipCertificate` → JCS canonicalization → `ed25519.Verify`.
- **Test Evidence:** `internal/engine/ownership/ownership_test.go:TestGoldenOwnershipScenarios/OWN-CERT-01_And_02_ValidGenesisCertificate` (PASS).
- **Limitation:** Payload is strictly per-asset (`AssetID string`). No collection, bundle, or `AlbumID` field exists.

#### Evidence Record: `EVID-C02`
- **Workstream:** C
- **Status:** `NOT FOUND IN EXAMINED SCOPE`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/`, `internal/engine/ownership/`, `pkg/nexa/`
- **Line Range:** N/A
- **Symbol:** N/A (`AlbumOwnershipCertificate`, `PublisherOriginAuthority`)
- **Technical Finding:** No data structure, method, or schema exists in the codebase to assert or verify Album-wide ownership or publisher origin across multiple member assets.
- **Limitation:** Cannot prove Album-wide authority using existing Sprint 11 ownership code without an architectural adapter or new declaration schema.

---

### Group D: Registry Authority / Federated Trust Proof

#### Evidence Record: `EVID-D01`
- **Workstream:** D
- **Status:** `PRESENT`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/registry_identity.go`
- **Line Range:** lines 13–63
- **Symbol:** `RegistryIdentity`, `CanonicalJCS`, `VerifySignature`
- **Technical Finding:** Registry identity carries `RegistryID`, `PublicKey`, `EndpointURL`, `APIVersion`, `IssuedAt`, `ExpiresAt` (14-day window), and `IdentitySignature`. Signature verified using Ed25519 over deterministic JCS string with 5-minute clock skew guard.
- **Verification Call Chain:** Called by `Evaluator.queryRegistry` during Level 1 Registry trust verification.
- **Test Evidence:** `internal/engine/federation/evaluator_test.go:TestLevel1IdentityVerificationSuite` (PASS).
- **Limitation:** Attests to the Registry's own service identity and endpoint, not an attestation over specific assets or albums.

#### Evidence Record: `EVID-D02`
- **Workstream:** D
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/engine/federation/evaluator.go`
- **Line Range:** lines 57–190, 203–273
- **Symbol:** `Evaluator.Evaluate`, `Evaluator.queryRegistry`
- **Technical Finding:** Performs multi-registry federation queries. Checks pinned keys (`AllowUnpinnedRegistries = false` fail-closed), queries `/v1/identity` and `/v1/certificates/{certID}`, and resolves consensus into `ACTIVE`, `REVOKED`, `CONFLICT`, or `UNKNOWN`.
- **Verification Call Chain:** Called by ecosystem APIs and verification services.
- **Test Evidence:** `internal/engine/federation/evaluator_test.go:TestGoActiveRevokedConflictTraceability`, `TestUnpinnedRegistryFailClosedPolicy` (PASS).
- **Limitation:** Requires live HTTP requests. If registries are empty or unreachable, returns `UNKNOWN / INCOMPLETE`. No offline embedded proof structure exists.

---

### Group E: Revocation Proof / Status Snapshot

#### Evidence Record: `EVID-E01`
- **Workstream:** E
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/identity.go`, `internal/engine/identity/verifier.go`
- **Line Range:** `domain/identity.go:L146-L175`, `verifier.go:L28, L239-L245`
- **Symbol:** `FreshnessContext`, `RevocationFinality`, `IdentityVerifier.ExecutePipeline`
- **Technical Finding:** `ExecutePipeline` accepts `isRevoked bool` and `isOffline bool`. If `isRevoked == true`, sets `StateRevoked` and `RevocationFinalityRecoverable`. Freshness is tracked as `ONLINE_FRESH` or `OFFLINE_CACHED`.
- **Verification Call Chain:** Direct argument evaluation in Step 5 of `ExecutePipeline`.
- **Test Evidence:** `tests/identity/verifier_test.go:TestVerificationPipelineVerified` (PASS).
- **Limitation:** Revocation is evaluated as an externally-supplied boolean flag, not by verifying a signed `RevocationAssertion` or snapshot payload.

#### Evidence Record: `EVID-E02`
- **Workstream:** E
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/registry_identity.go`, `internal/domain/ownership.go`
- **Line Range:** `registry_identity.go:L24-L29`, `ownership.go:L104`
- **Symbol:** `RegistryKeyRevocationList`, `OwnershipEvent` (EventType="REVOCATION")
- **Technical Finding:** `RegistryKeyRevocationList` carries hex-encoded revoked key hashes signed by Registry (`ListSignature`). `OwnershipEvent` records `EventType="REVOCATION"` with timestamp `RecordedAt`.
- **Verification Call Chain:** Read by registry service and ownership event store.
- **Test Evidence:** `tests/identity/regression_test.go:TestValidateRevocationKeyScope` (PASS).
- **Limitation:** No dual-horizon evaluation comparing `revoked_at` (signer time) vs `recorded_at` (registry ledger time) exists in verification logic.

---

### Group F: Tier-2 Membership Authority / Album Signer Identity and Delegation

#### Evidence Record: `EVID-F01`
- **Workstream:** F
- **Status:** `PARTIAL`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** `internal/domain/identity.go`, `internal/engine/identity/delegation.go`
- **Line Range:** `domain/identity.go:L124-L144`, `delegation.go:L13-L115`
- **Symbol:** `DelegationAssertion`, `VerifyDelegationAssertion`, `CheckScopeSubsetting`, `CheckSubdelegationDepth`
- **Technical Finding:** Defines 3-level scoped delegation. Verifies parent Ed25519 signature over JCS canonical payload. Enforces maximum depth <= 2 (`CheckSubdelegationDepth`) and strict scope subsetting (`CheckScopeSubsetting`).
- **Verification Call Chain:** `ResolveDelegatedAuthorityChain` → `VerifyDelegationAssertion` → `crypto.CanonicalizeJCS` → `ed25519.Verify`.
- **Test Evidence:** `tests/identity/delegation_test.go:TestThreeLevelDelegationAuthorityChain` (PASS), `tests/audit/sprint14/delegation_audit_test.go:TestAuditThreeLevelDelegationAuthorityChain` (PASS).
- **Limitation:** Delegated scopes are generic strings; no `album_id` attribute exists on `DelegationAssertion`.

#### Evidence Record: `EVID-F02`
- **Workstream:** F
- **Status:** `NOT FOUND IN EXAMINED SCOPE`
- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Source Path:** All repositories and modules
- **Line Range:** N/A
- **Symbol:** `ALBUM_MEMBERSHIP_SIGNING`
- **Technical Finding:** Searched across entire repository (`grep -rnw "ALBUM_MEMBERSHIP_SIGNING" .`). Exactly 0 matches found.
- **Limitation:** The capability purpose token, its binding to exact `album_id`, and verifier integration into Album Manifest validation do not exist in existing code.

---

## 3. RAW SOURCE EXCERPTS

### Excerpt 1: IdentityAssertion & Subject ID Derivation
**File:** `internal/domain/identity.go#L62-L78`
```go
type IdentityAssertion struct {
	SpecVersion        string                `json:"spec_version"`
	AssertionID        string                `json:"assertion_id"`
	SubjectID          string                `json:"subject_id"`
	SubjectType        SubjectType           `json:"subject_type"`
	GenesisRootKey     string                `json:"genesis_root_key"`
	CurrentRootKey     string                `json:"current_root_key"`
	ActivePublicKey    string                `json:"active_public_key"`
	RecoveryKeyDigest  TriStateValue[string] `json:"recovery_key_digest"`
	IssuedAt           string                `json:"issued_at"`
	EffectiveAt        string                `json:"effective_at"`
	ExpiresAt          string                `json:"expires_at"`
	Nonce              string                `json:"nonce"`
	SignatureAlgorithm string                `json:"signature_algorithm"`
	Metadata           map[string]string     `json:"metadata,omitempty"`
	Signature          string                `json:"signature"`
}
```
**File:** `internal/engine/identity/subject.go#L13-L20`
```go
func DeriveSubjectID(rawGenesisEd25519PubKeyBytes []byte) (string, error) {
	if len(rawGenesisEd25519PubKeyBytes) != 32 {
		return "", fmt.Errorf("invalid raw ed25519 public key length: expected 32 bytes, got %d", len(rawGenesisEd25519PubKeyBytes))
	}
	hash := sha256.Sum256(rawGenesisEd25519PubKeyBytes)
	hexHash := hex.EncodeToString(hash[:])
	return FormatSubjectIDURN(hexHash), nil
}
```

### Excerpt 2: Root Recovery 2-Step Protocol
**File:** `internal/engine/identity/lineage.go#L46-L84`
```go
	// Step 1: Digest match
	digestHash := sha256.Sum256(recPubKeyBytes)
	computedDigest := hex.EncodeToString(digestHash[:])
	if !strings.EqualFold(computedDigest, strings.TrimSpace(*genesisRecoveryKeyDigest)) {
		return fmt.Errorf("%s: recovery public key digest mismatch", domain.ErrCodeUnauthorizedRecovery)
	}

	// Step 2: Cryptographic Signature Verification using recovery_public_key
	sigBytes, err := hex.DecodeString(strings.TrimSpace(assertion.Signature))
	if err != nil || len(sigBytes) != 64 {
		return fmt.Errorf("%s: invalid recovery signature hex encoding or length", domain.ErrCodeMalformedEvidence)
	}

	payloadToVerify := map[string]interface{}{
		"spec_version":         assertion.SpecVersion,
		"assertion_type":       assertion.AssertionType,
		"assertion_id":         assertion.AssertionID,
		"subject_id":           assertion.SubjectID,
		"genesis_root_key":     assertion.GenesisRootKey,
		"compromised_root_key": assertion.CompromisedRootKey,
		"recovery_public_key":  assertion.RecoveryPublicKey,
		"successor_root_key":   assertion.SuccessorRootKey,
		"issued_at":            assertion.IssuedAt,
		"effective_at":         assertion.EffectiveAt,
		"expires_at":           assertion.ExpiresAt,
		"nonce":                assertion.Nonce,
		"signature_algorithm":  assertion.SignatureAlgorithm,
	}

	canonicalBytes, err := crypto.CanonicalizeJCS(payloadToVerify)
	if err != nil {
		return fmt.Errorf("%s: failed to canonicalize recovery assertion payload: %w", domain.ErrCodeMalformedEvidence, err)
	}

	pubKey := ed25519.PublicKey(recPubKeyBytes)
	if !ed25519.Verify(pubKey, canonicalBytes, sigBytes) {
		return fmt.Errorf("%s: invalid root recovery assertion signature", domain.ErrCodeUnauthorizedRecovery)
	}
```

### Excerpt 3: Active Key Authorization & Monotonic Sequence
**File:** `internal/engine/identity/active_key.go#L122-L150`
```go
	// Sort by SequenceNumber ascending
	sort.Slice(validInPeriod, func(i, j int) bool {
		return validInPeriod[i].SequenceNumber < validInPeriod[j].SequenceNumber
	})

	// Check for sequence continuity and competing assertion conflicts
	seenSeq := make(map[int64]*domain.ActiveKeyAuthorizationAssertion)
	for idx, assertion := range validInPeriod {
		if existing, found := seenSeq[assertion.SequenceNumber]; found {
			if !strings.EqualFold(existing.ActivePublicKey, assertion.ActivePublicKey) {
				return "", fmt.Errorf("%s: competing active key assertions for sequence %d", domain.ErrCodeActiveKeyConflict, assertion.SequenceNumber)
			}
		}
		seenSeq[assertion.SequenceNumber] = assertion

		if idx == 0 {
			if assertion.SequenceNumber != 1 || assertion.PreviousActiveKey != nil {
				return "", fmt.Errorf("%s: initial active key assertion MUST have sequence_number=1 and previous_active_key=null", domain.ErrCodeInvalidActiveKeyProof)
			}
		} else {
			pred := validInPeriod[idx-1]
			if assertion.SequenceNumber != pred.SequenceNumber+1 {
				return "", fmt.Errorf("%s: active key sequence gap: expected %d, got %d", domain.ErrCodeInvalidActiveKeyProof, pred.SequenceNumber+1, assertion.SequenceNumber)
			}
			if assertion.PreviousActiveKey == nil || !strings.EqualFold(*assertion.PreviousActiveKey, pred.ActivePublicKey) {
				return "", fmt.Errorf("%s: active key predecessor key mismatch", domain.ErrCodeInvalidActiveKeyProof)
			}
		}
	}
```

### Excerpt 4: Delegation Assertion & Subdelegation Bounds
**File:** `internal/engine/identity/delegation.go#L99-L114`
```go
func CheckSubdelegationDepth(assertion *domain.DelegationAssertion) error {
	if assertion == nil {
		return fmt.Errorf("%s: delegation assertion is nil", domain.ErrCodeMalformedEvidence)
	}

	if assertion.DelegatorLevel >= 2 || assertion.CurrentDepth >= 2 {
		return fmt.Errorf("%s: Level 2 keys MUST NOT delegate (max depth reached)", domain.ErrCodeInvalidDelegationChain)
	}

	if assertion.MaxDelegationDepth > 0 && assertion.CurrentDepth >= assertion.MaxDelegationDepth {
		return fmt.Errorf("%s: maximum delegation depth exceeded (%d >= %d)", domain.ErrCodeInvalidDelegationChain, assertion.CurrentDepth, assertion.MaxDelegationDepth)
	}

	return nil
}
```

---

## 4. SIGNED PAYLOAD & SIGNATURE SEMANTICS

| Object Type | Serializer / Canonicalizer | Included Fields in Preimage | Excluded Fields | Verification Function | Key Used |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`IdentityAssertion`** | RFC 8785 JCS via `crypto.CanonicalizeJCS` | `spec_version`, `assertion_id`, `subject_id`, `subject_type`, `genesis_root_key`, `current_root_key`, `active_public_key`, `recovery_key_digest`, `issued_at`, `effective_at`, `expires_at`, `nonce`, `signature_algorithm` | `signature`, `metadata` | `ed25519.Verify` in `IdentityVerifier.ExecutePipeline:L224` | `ActivePublicKey` (resolved via `ResolveActiveSigningAuthorityAt`) |
| **`RootRecoveryAssertion`** | RFC 8785 JCS via `crypto.CanonicalizeJCS` | `spec_version`, `assertion_type`, `assertion_id`, `subject_id`, `genesis_root_key`, `compromised_root_key`, `recovery_public_key`, `successor_root_key`, `issued_at`, `effective_at`, `expires_at`, `nonce`, `signature_algorithm` | `signature` | `ed25519.Verify` in `Verify2StepRootRecovery:L82` | `RecoveryPublicKey` (matching `genesis_recovery_key_digest`) |
| **`ActiveKeyAuthorizationAssertion`** | RFC 8785 JCS via `crypto.CanonicalizeJCS` | `spec_version`, `assertion_type`, `assertion_id`, `subject_id`, `authorizing_root_key`, `active_public_key`, `sequence_number`, `previous_active_key`, `issued_at`, `effective_at`, `expires_at`, `nonce`, `signature_algorithm` | `signature` | `ed25519.Verify` in `VerifyActiveKeyAssertion:L85` | `AuthorizingRootKey` (resolved via `ResolveRootAuthorityAt(EffectiveAt)`) |
| **`DelegationAssertion`** | RFC 8785 JCS via `crypto.CanonicalizeJCS` | `spec_version`, `assertion_type`, `assertion_id`, `subject_id`, `delegator_subject_id`, `delegator_level`, `parent_public_key`, `delegate_public_key`, `delegated_scope`, `allow_subdelegation`, `max_delegation_depth`, `current_depth`, `issued_at`, `effective_at`, `expires_at`, `nonce`, `signature_algorithm` | `signature` | `ed25519.Verify` in `VerifyDelegationAssertion:L76` | `ParentPublicKey` |
| **`RegistryIdentity`** | Handcrafted compact JCS in `CanonicalJCS()` | `api_version`, `endpoint_url`, `expires_at`, `issued_at`, `public_key`, `registry_id` | `identity_signature`, `supported_features` | `ed25519.Verify` in `RegistryIdentity.VerifySignature:L62` | `PublicKey` (self-signed, verified against pinned key) |
| **`OwnershipCertificate`** | Custom RFC 8785 JCS in `CanonicalizeGenesisPayload` | `asset_id`, `creator_public_key`, `effective_at`, `issued_at`, `issuer_id`, `previous_cert_ref`, `subject_id`, `underlying_cert_id` | `creator_signature`, `issuer_signature`, `metadata`, `status`, `ownership_cert_id`, `signature_algorithm` | `ed25519.Verify` in `VerifyOwnershipCertificate` | Dual: `CreatorPublicKey` + `IssuerPublicKey` |

---

## 5. VERIFICATION CALL CHAINS

### 1. Identity Verification Call Chain
```
IdentityAssertion JSON Input
  → json.Unmarshal
  → IdentityVerifier.ExecutePipeline
      ├── [Step 1] Structural & JCS validation (timestamps, tri-state recovery digest, privacy bounds)
      ├── [Step 2] ResolveRootAuthorityAt(GenesisRootKey, TargetTimestamp)
      │       └── Verify2StepRootRecovery(RootRecoveryAssertion)
      │               ├── Step 1: sha256(RecoveryPublicKey) == GenesisRecoveryKeyDigest
      │               └── Step 2: ed25519.Verify(RecoveryPublicKey, JCS(RecoveryAssertion))
      ├── [Step 3] ResolveActiveSigningAuthorityAt(GenesisRootKey, TargetTimestamp)
      │       └── VerifyActiveKeyAssertion(ActiveKeyAuthorizationAssertion)
      │               ├── ResolveRootAuthorityAt(EffectiveAt)
      │               └── ed25519.Verify(AuthorizingRootKey, JCS(ActiveKeyAssertion))
      ├── [Step 4] ed25519.Verify(ActiveSigningKey, JCS(IdentityAssertion))
      └── [Step 5] Expiry and Revocation check
  → VerificationResult (VERIFIED / INVALID / EXPIRED / REVOKED / CONFLICT / INCOMPLETE)
```

### 2. Delegation Verification Call Chain
```
DelegationAssertion JSON Input
  → json.Unmarshal
  → ResolveDelegatedAuthorityChain
      ├── ResolveRootAuthorityAt(GenesisRootKey, TargetTimestamp)
      ├── VerifyDelegationAssertion(DelegationAssertion)
      │       └── ed25519.Verify(ParentPublicKey, JCS(DelegationAssertion))
      ├── CheckSubdelegationDepth (CurrentDepth < 2, DelegatorLevel < 2)
      └── CheckScopeSubsetting (child_scope ⊆ parent_scope)
  → Validated Delegation Chain
```

### 3. Album Manifest Integration Call Chain
```
Album Manifest Input
  → [CALL CHAIN INCOMPLETE / NOT FOUND]
  (No caller in player-desktop, player-mobile, verify-desktop, or studio-desktop connects Album Manifest parsing to IdentityVerifier or ResolveDelegatedAuthorityChain)
```

---

## 6. OFFLINE DEPENDENCY MAPPING

| Workstream | In-Payload Material | Local Storage / Cache Requirement | Online Network Dependency | Can Verify Offline? |
| :--- | :--- | :--- | :--- | :--- |
| **A (Genesis Identity)** | `IdentityAssertion` | Pre-pinned Root Key (if external trust anchor needed) | None (self-contained verification) | **YES** (mathematically verified offline) |
| **B (Key Lineage & Recovery)** | `RootRecoveryAssertion` list, `ActiveKeyAuthorizationAssertion` list | None | None | **YES** (evaluates historical lineage offline) |
| **C (Ownership)** | `OwnershipCertificate` | None | None for per-asset; Album-wide **NOT FOUND** | **YES** for scalar asset; **NO** for Album |
| **D (Registry Authority)** | None (only online target URL) | Pinned `PublicKey` in `RegistryTarget` | Live HTTP to `/v1/identity` and `/v1/certificates` | **NO** (Evaluator fails closed without network) |
| **E (Revocation)** | `isRevoked` flag (if embedded) | `RegistryKeyRevocationList` cache | Registry/Event Store query for current status | **PARTIAL** (offline verified against cached/embedded horizon; cannot detect post-issuance revocations) |
| **F (Delegation / Signer)** | `DelegationAssertion` | None | None | **YES** for generic delegation; **NO** for Album capability (`NOT FOUND`) |

---

## 7. GAPS & LIMITATIONS IDENTIFIED

1. **GAP-MAP-01 (Trust Anchor Model):** `IdentityVerifier.ExecutePipeline` verifies cryptographic consistency between `GenesisRootKey` and `SubjectID`, but has no trust-anchor pinning store for Genesis roots.
2. **GAP-MAP-02 (Individual Key Lineage):** Individual Creator subjects have no active key rotation or recovery assertion model distinct from Organization.
3. **GAP-MAP-03 (Album-wide Ownership):** `OwnershipCertificate` is strictly bound to scalar `asset_id`. No multi-member album ownership or publisher-origin certificate exists.
4. **GAP-MAP-04 (Offline Registry Proof):** `Evaluator.Evaluate` is strictly an online HTTP engine. There is no offline cryptographic attestation structure produced by Registries that can be embedded in an album manifest.
5. **GAP-MAP-05 (Standalone Revocation Proof):** No signed `RevocationAssertion` exists for identity or delegation. Dual-horizon time logic (`revoked_at` vs `recorded_at`) is not implemented in verifiers.
6. **GAP-MAP-06 (Album Signing Scope & ID Binding):** `ALBUM_MEMBERSHIP_SIGNING` scope does not exist in any enum or allowlist. `DelegationAssertion` lacks an `album_id` attribute.

---

## 8. QUESTIONS REQUIRING AA ARCHITECTURAL DECISIONS

1. **Embedding vs Wrapping:** Should native objects (`IdentityAssertion`, `RootRecoveryAssertion`, `ActiveKeyAuthorizationAssertion`, `DelegationAssertion`) be embedded directly as sub-objects in `Album Manifest` (preserving their native JCS schemas), or wrapped in a dedicated PE-02 envelope?
2. **Album Authority Designation Schema:** Since `OwnershipCertificate` is strictly per-asset, how should the Tier-1 Album Origin Declaration be represented? (e.g., a dedicated `AlbumOriginDeclaration` carrying `album_id`, `designated_authority_subject_id`, signed by the Creator/Publisher Genesis Key).
3. **Scoping in DelegationAssertion:** Should `album_id` be bound via a parameterized scope string in `DelegatedScope` (e.g. `ALBUM_MEMBERSHIP_SIGNING:<album_id>`), or should a dedicated `album_id` field be added to a new assertion type?
4. **Offline Registry Representation:** For A1 Complete Evidence Closure, does Tier-1 require an embedded offline Registry endorsement, or is offline cryptographic closure satisfied by the Creator/Organization Genesis Identity + Key Lineage?
