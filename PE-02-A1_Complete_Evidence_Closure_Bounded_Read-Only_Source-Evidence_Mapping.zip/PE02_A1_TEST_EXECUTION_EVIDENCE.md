# NEXA PE-02 — A1 COMPLETE EVIDENCE CLOSURE
## TEST EXECUTION EVIDENCE

- **Repository:** `whisnu/nexa`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Execution Date:** 2026-11-10
- **Working Directory:** `/opt/antigravity/projects/nexa`
- **Environment Note:** Tests executed with `GOTMPDIR=/opt/antigravity/projects/nexa/scratch/gotmp` to satisfy workspace execution policies.

---

### Test Suite 1: Identity Unit Tests (`tests/identity/...`)
- **Command:** `GOTMPDIR=/opt/antigravity/projects/nexa/scratch/gotmp go test -v ./tests/identity/...`
- **Exit Code:** `0`
- **Result:** `PASS`
- **Raw Output:**
```text
=== RUN   TestActiveKeyAuthorizationSequenceRules
--- PASS: TestActiveKeyAuthorizationSequenceRules (0.00s)
=== RUN   TestThreeLevelDelegationAuthorityChain
--- PASS: TestThreeLevelDelegationAuthorityChain (0.00s)
=== RUN   TestRFC8785AuthoritativeIndependentConformanceCorpus
--- PASS: TestRFC8785AuthoritativeIndependentConformanceCorpus (0.00s)
=== RUN   TestRFC8785InvalidUnicodeFailClosedRejection
--- PASS: TestRFC8785InvalidUnicodeFailClosedRejection (0.00s)
=== RUN   TestSignatureInteroperabilityVector
--- PASS: TestSignatureInteroperabilityVector (0.00s)
=== RUN   TestRootLineageFailureMappings
--- PASS: TestRootLineageFailureMappings (0.00s)
=== RUN   TestRecoveryKeyDigestJSONPresence
--- PASS: TestRecoveryKeyDigestJSONPresence (0.00s)
=== RUN   TestVerify2StepRootRecovery
--- PASS: TestVerify2StepRootRecovery (0.00s)
=== RUN   TestUnboundedRecoveryLineageDepth
--- PASS: TestUnboundedRecoveryLineageDepth (0.01s)
=== RUN   TestClosedBaselineRegressionProtection
--- PASS: TestClosedBaselineRegressionProtection (0.15s)
=== RUN   TestDeriveSubjectID
--- PASS: TestDeriveSubjectID (0.00s)
=== RUN   TestVerifySubjectIDContinuity
--- PASS: TestVerifySubjectIDContinuity (0.00s)
=== RUN   TestVerificationPipelineVerified
--- PASS: TestVerificationPipelineVerified (0.00s)
=== RUN   TestValidateRevocationKeyScope
--- PASS: TestValidateRevocationKeyScope (0.00s)
PASS
ok  	nexa/tests/identity	0.184s
```

---

### Test Suite 2: Sprint 14 Identity Audit Tests (`tests/audit/sprint14/...`)
- **Command:** `GOTMPDIR=/opt/antigravity/projects/nexa/scratch/gotmp go test -v ./tests/audit/sprint14/...`
- **Exit Code:** `0`
- **Result:** `PASS`
- **Raw Output:**
```text
=== RUN   TestAuditActiveKeyAuthorizationSequenceRules
--- PASS: TestAuditActiveKeyAuthorizationSequenceRules (0.00s)
=== RUN   TestAuditThreeLevelDelegationAuthorityChain
--- PASS: TestAuditThreeLevelDelegationAuthorityChain (0.00s)
=== RUN   TestAuditRevocationAuthorityValidation
--- PASS: TestAuditRevocationAuthorityValidation (0.00s)
=== RUN   TestAuditRFC8785IndependentJCSCorpus
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-01
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-02
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-03
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-04
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-05
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-06
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-07
=== RUN   TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-08
--- PASS: TestAuditRFC8785IndependentJCSCorpus (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-01 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-02 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-03 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-04 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-05 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-06 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-07 (0.00s)
    --- PASS: TestAuditRFC8785IndependentJCSCorpus/JCS-AUDIT-VEC-08 (0.00s)
=== RUN   TestAuditRFC8785InvalidUnicodeFailClosedRejection
[JCS-AUDIT-VEC-09] Invalid UTF-8 fail-closed rejection verified: JCS pre-marshal Unicode validation failed: invalid UTF-8 string byte sequence
--- PASS: TestAuditRFC8785InvalidUnicodeFailClosedRejection (0.00s)
=== RUN   TestAuditMultiStepLineageResolution
--- PASS: TestAuditMultiStepLineageResolution (0.01s)
=== RUN   TestAuditLineageBranchingConflict
--- PASS: TestAuditLineageBranchingConflict (0.00s)
=== RUN   TestAuditTriStateRecoveryCommitment
--- PASS: TestAuditTriStateRecoveryCommitment (0.00s)
=== RUN   TestAudit2StepRecoveryProtocol
--- PASS: TestAudit2StepRecoveryProtocol (0.00s)
=== RUN   TestAuditSprint10Regression
--- PASS: TestAuditSprint10Regression (0.00s)
=== RUN   TestAuditSprint11Regression
--- PASS: TestAuditSprint11Regression (0.00s)
=== RUN   TestAuditSprint112Regression
--- PASS: TestAuditSprint112Regression (0.00s)
=== RUN   TestAuditSprint12Regression
--- PASS: TestAuditSprint12Regression (0.00s)
=== RUN   TestAuditSprint13Regression
--- PASS: TestAuditSprint13Regression (0.14s)
=== RUN   TestAuditPublicSDKAdaptation
--- PASS: TestAuditPublicSDKAdaptation (0.00s)
=== RUN   TestAuditSubjectIDDerivationAndInvariance
--- PASS: TestAuditSubjectIDDerivationAndInvariance (0.00s)
PASS
ok  	nexa/tests/audit/sprint14	0.163s
```

---

### Test Suite 3: Ownership Engine Tests (`internal/engine/ownership/...`)
- **Command:** `GOTMPDIR=/opt/antigravity/projects/nexa/scratch/gotmp go test -v ./internal/engine/ownership/...`
- **Exit Code:** `0`
- **Result:** `PASS`
- **Raw Output:**
```text
=== RUN   TestGoldenOwnershipScenarios
=== RUN   TestGoldenOwnershipScenarios/OWN-CERT-01_And_02_ValidGenesisCertificate
=== RUN   TestGoldenOwnershipScenarios/OWN-CERT-05_InvalidCreatorSignatureRejection
=== RUN   TestGoldenOwnershipScenarios/OWN-TRANSFER-01_ValidUnilateralTransfer
=== RUN   TestGoldenOwnershipScenarios/OWN-HISTORY-01_SequentialLineageEvaluation
=== RUN   TestGoldenOwnershipScenarios/OWN-DELEGATION-01_And_04_ClosedScopeAllowlist
=== RUN   TestGoldenOwnershipScenarios/OWN-CONFLICT-01_MultiBranchConflictPreservation
=== RUN   TestGoldenOwnershipScenarios/OWN-COMPAT-01_LegacyAssetBackwardCompatibility
=== RUN   TestGoldenOwnershipScenarios/OWN-SECURITY-01_ReplayProtection
=== RUN   TestGoldenOwnershipScenarios/OWN-TRANSFER-02_UnauthorizedTransferRejection
=== RUN   TestGoldenOwnershipScenarios/OWN-FEDERATION-01A_MultiRegistryConsistentEvidence
=== RUN   TestGoldenOwnershipScenarios/OWN-FEDERATION-01B_MultiRegistryContradictoryValidEvidence
--- PASS: TestGoldenOwnershipScenarios (0.01s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-CERT-01_And_02_ValidGenesisCertificate (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-CERT-05_InvalidCreatorSignatureRejection (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-TRANSFER-01_ValidUnilateralTransfer (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-HISTORY-01_SequentialLineageEvaluation (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-DELEGATION-01_And_04_ClosedScopeAllowlist (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-CONFLICT-01_MultiBranchConflictPreservation (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-COMPAT-01_LegacyAssetBackwardCompatibility (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-SECURITY-01_ReplayProtection (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-TRANSFER-02_UnauthorizedTransferRejection (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-FEDERATION-01A_MultiRegistryConsistentEvidence (0.00s)
    --- PASS: TestGoldenOwnershipScenarios/OWN-FEDERATION-01B_MultiRegistryContradictoryValidEvidence (0.00s)
PASS
ok  	nexa/internal/engine/ownership	0.009s
```

---

### Test Suite 4: Federation Evaluator Tests (`internal/engine/federation/...`)
- **Command:** `GOTMPDIR=/opt/antigravity/projects/nexa/scratch/gotmp go test -v ./internal/engine/federation/...`
- **Exit Code:** `0`
- **Result:** `PASS`
- **Raw Output:**
```text
=== RUN   TestAssetIsolationForLocalOverride
    evaluator_test.go:43: R-05 Asset Isolation Test Passed: Asset A override did NOT affect Asset B!
--- PASS: TestAssetIsolationForLocalOverride (0.00s)
=== RUN   TestNonMutationOverlayInvariant
    evaluator_test.go:97: R-06 Non-Mutation Overlay Invariant Test Passed!
--- PASS: TestNonMutationOverlayInvariant (0.00s)
=== RUN   TestExpiredAndNoTrustedRegistrySemantics
    evaluator_test.go:126: R-02 / R-03 Expired & No Trusted Registry Test Passed!
--- PASS: TestExpiredAndNoTrustedRegistrySemantics (0.00s)
=== RUN   TestUnpinnedRegistryFailClosedPolicy
    evaluator_test.go:154: Correction 5 Unpinned Registry Fail-Closed Policy Test Passed!
--- PASS: TestUnpinnedRegistryFailClosedPolicy (0.00s)
=== RUN   TestLevel1IdentityVerificationSuite
    evaluator_test.go:174: FC-04 Level 1 Identity Failure Verification Passed!
--- PASS: TestLevel1IdentityVerificationSuite (0.00s)
=== RUN   TestNonMutationOverlayInvariantByteLevel
    evaluator_test.go:220: FC-06 Byte-Level Non-Mutation Invariant Verified PASS!
--- PASS: TestNonMutationOverlayInvariantByteLevel (0.00s)
=== RUN   TestGoActivePartialFederationSemantics
    evaluator_test.go:251: C-02 Real Go ACTIVE + PARTIAL Test Passed!
--- PASS: TestGoActivePartialFederationSemantics (0.00s)
=== RUN   TestGoActiveRevokedConflictTraceability
    evaluator_test.go:286: C-03 Real ACTIVE + REVOKED -> CONFLICT Traceability Test Passed!
--- PASS: TestGoActiveRevokedConflictTraceability (0.00s)
PASS
ok  	nexa/internal/engine/federation	0.005s
```

---

### Test Suite Summary
- **Total Test Cases Executed:** 43 tests
- **Passed:** 43
- **Failed:** 0
- **Not Run:** 0 (all available tests in examined scope executed successfully)
