# AUDIT-NEW-10_INSPECTION_MANIFEST.md
# MANIFEST KETERLACAKAN INSPEKSI (INSPECTION MANIFEST)
## AUDIT-NEW-10 — Three-Way Identity Binding dan Third-Party Packaging Delegation

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956` (Identik dengan `origin/main`)
- **Waktu Inspeksi:** 10 November 2026, 09:37 – 09:41 UTC+7
- **Lingkungan Kerja:** Linux x86_64, Node.js v22.23.4, Go 1.22.4

---

### 1. Berkas dan Simbol yang Diperiksa

| Path File | Rentang Baris | Simbol / Fungsi / Interface | Peran dalam Arsitektur |
|---|---|---|---|
| `sdk/typescript/src/sdk.ts` | L1–L50 | `Manifest`, `VerificationResult` | Definisi struktur output verifikasi SDK |
| `sdk/typescript/src/sdk.ts` | L133–L290 | `verifyContainer` | Alur verifikasi kontainer, IPC gateway, hardcoded equality check |
| `sdk/typescript/src/ownership.ts` | L1–L40 | `AllowedDelegationScopes`, `ScopeMetadataUpdateClaim`, dll. | Allowlist scope tertutup |
| `sdk/typescript/src/ownership.ts` | L50–L78 | `OwnershipDelegation`, `OwnershipVerificationResult` | Struktur data delegasi dan evaluasi kepemilikan TS |
| `sdk/typescript/src/ownership.ts` | L131–L156 | `canonicalizeDelegationPayload` | Serializer RFC 8785 JCS payload delegasi |
| `sdk/typescript/src/ownership.ts` | L239–L343 | `verifyGenesisCertificate`, `evaluateOwnershipEvidenceTS` | Evaluasi rantai kepemilikan dan penyaringan delegasi |
| `internal/domain/ownership.go` | L1–L40 | `IsValidDelegationScope`, konstanta scope | Penegakan closed allowlist scope pada Go domain |
| `internal/engine/ownership/delegation.go` | L15–L52 | `CanonicalizeDelegationPayload` | Serializer RFC 8785 JCS di Go engine |
| `internal/engine/ownership/delegation.go` | L54–L151 | `CreateOwnershipDelegation`, `VerifyDelegationSignature`, `IsDelegationActive` | Pembuatan dan verifikasi kriptografi delegasi di Go |
| `sdk/typescript/src/registry.ts` | L1–L50 | `RegistryCert`, `NexaRegistryClient` | Klien registri identitas dan sertifikat |
| `sdk/typescript/src/registry.ts` | L105–L123 | `canonicalJcs`, `formatJcsTimestamp` | Skema kanonikal 6-field yang ditandatangani Registry |
| `player-desktop/main.js` | L51, L700–L745 | `CANONICAL_REGISTRY_PUBKEY`, `open-and-verify-nx` | Pinned trust anchor dan handler otorisasi Player |
| `verify-desktop/main.js` | L33, L300–L350 | `CANONICAL_REGISTRY_PUBKEY`, `verify-file` | Pinned trust anchor dan verifikasi Verify Desktop |
| `sdk/c/nexa_mobile_cbindings.go` | L290–L325 | `NEXA_CANONICAL_REGISTRY_PUBKEY_HEX` | Fallback trust anchor pada runtime mobile |
| `test/pe01_tampered_sidecar_test.js` | L50–L150 | `executeDesktopVerificationPipeline` | Validasi tampered sidecar dan mitigasi manipulasi |
| `test/task_a_final_trust_boundary_test.js` | L85–L178 | Kasus A & Kasus B | Falsifikasi trust boundary Registry vs Genesis |

---

### 2. Berkas Pengujian yang Dijalankan Nyata (*Empirically Executed*)

1. `sdk/typescript/test/ownership_parity.test.js` -> `PASS (5/5)`
2. `sdk/typescript/test/registry_identity.test.js` -> `PASS (8/8)`
3. `sdk/typescript/test/federation_parity.test.js` -> `PASS (5/5)`
4. `internal/engine/ownership/ownership_test.go` -> `PASS (11/11)`
5. `test/task_a_final_trust_boundary_test.js` -> `PASS (2/2)`
6. `test/pe01_tampered_sidecar_test.js` -> `PASS (6/6)`

---

### 3. Berkas yang Gagal Diakses / Akses Terbatas

- **Berkas Gagal Diakses:** **TIDAK ADA / NONE** (Seluruh berkas lokal pada `/opt/antigravity/projects/nexa/` dapat diakses dan dibaca dengan status exit code 0).

---

### 4. Simbol / Fitur yang TIDAK DITEMUKAN dalam Cakupan Inspeksi

1. `ScopeContainerPackaging` / `CONTAINER_PACKAGING`: **`NOT FOUND IN INSPECTED SCOPE`**
2. `verifyDelegationSignature` pada modul TypeScript: **`NOT FOUND IN INSPECTED SCOPE`**
3. Pemisahan `packagingAuthorityValid` pada `VerificationResult`: **`NOT FOUND IN INSPECTED SCOPE`**
4. Unit test untuk penolakan pemaket pihak ketiga tanpa delegasi: **`NOT FOUND IN INSPECTED SCOPE`**

---

### 5. Batas Cakupan dan Keterbatasan

- **Batas Inspeksi:** Inspeksi dilakukan secara statis dan pembuktian test unit/integrasi terisolasi pada lingkungan Linux x86_64 lokal.
- **Keterbatasan Runtime:** Tidak melibatkan koneksi ke server live production atau eksekusi emulator native Android/iOS fisik.
- **Batas Otoritas:** Temuan ini merefleksikan kode faktual pada commit `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`. Tidak ada perubahan implementasi, schema, test, atau otorisasi PE-02 yang diterbitkan oleh manifest ini.
