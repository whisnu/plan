# AUDIT-NEW-10_SOURCE_EVIDENCE.md
# LAMPIRAN BUKTI SUMBER (SOURCE EVIDENCE VERBATIM)
## AUDIT-NEW-10 — Three-Way Identity Binding dan Third-Party Packaging Delegation

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Status:** READ-ONLY VERBATIM EVIDENCE DUMP

---

### 1. Bukti Area 1: Hardcoded Equality Check pada SDK TypeScript

#### Cuplikan Verbatim 1.1: `sdk/typescript/src/sdk.ts` L133–L165
```typescript
export async function verifyContainer(nxPath: string, pubKey: crypto.KeyObject,
                                     registryURL?: string, registryPubKey?: crypto.KeyObject,
                                     cachedCert?: NexaRegistry.RegistryCert): Promise<VerificationResult> {
    const data = fs.readFileSync(nxPath);
    const container = NexaContainer.unpack(data);

    const manifestStr = container.manifestBytes.toString("utf8");
    const manifest = JSON.parse(manifestStr) as Manifest;

    // 1. Signature check
    const signatureValid = NexaCrypto.verify(pubKey, container.manifestBytes, container.signatureBytes);

    // 2. Hash check
    const computedHash = NexaCrypto.sha256(container.payloadBytes);
    const actualHashStr = computedHash.toString("hex");
    const hashValid = actualHashStr === manifest.asset_hash;

    // 3. Certificate ID calculation
    const hashOfSig = NexaCrypto.sha256(container.signatureBytes);
    const certID = hashOfSig.toString("hex");

    const res: VerificationResult = {
        signatureValid,
        hashValid,
        manifest,
        manifestBytes: container.manifestBytes,
        sha256Hash: actualHashStr,
        payload: container.payloadBytes,
        certificateID: certID,
        certificateStatus: "none",
        registryVerified: false,
        registryError: ""
    };
```
- **Konteks & Makna Kriptografis:**
  - Argumen `pubKey` langsung dipasok ke `NexaCrypto.verify(pubKey, container.manifestBytes, container.signatureBytes)`.
  - Ini membuktikan bahwa `pubKey` adalah kunci yang menandatangani manifest trailer biner `.nx`, yaitu **`containerSigKey`**.

#### Cuplikan Verbatim 1.2: `sdk/typescript/src/sdk.ts` L232–L264 (Equality Check & Evaluasi Kepemilikan)
```typescript
        // Structural integrity verification of embedded Genesis Ownership Certificate (if present)
        let ownershipVerified = false;
        const ownCert = (regCert as any).ownership_certificate;
        if (ownCert && ownCert.creator_public_key && ownCert.creator_signature) {
            try {
                let creatorMatches = true;
                if (pubKey) {
                    const rawCreatorPubKey = NexaCrypto.getRawPublicKey(pubKey).toString("hex");
                    creatorMatches = (ownCert.creator_public_key === rawCreatorPubKey);
                }
                const canonGenesisStr = JSON.stringify({
                    asset_id: ownCert.asset_id,
                    creator_public_key: ownCert.creator_public_key,
                    effective_at: ownCert.effective_at,
                    issued_at: ownCert.issued_at,
                    issuer_id: ownCert.issuer_id,
                    previous_cert_ref: ownCert.previous_cert_ref || "",
                    subject_id: ownCert.subject_id,
                    underlying_cert_id: ownCert.underlying_cert_id
                });
                const ownSigBytes = Buffer.from(ownCert.creator_signature, "hex");
                const ownKeyObj = NexaCrypto.loadPublicKey(ownCert.creator_public_key);
                const certIdMatches = (!ownCert.underlying_cert_id || ownCert.underlying_cert_id === certID);
                const cryptoValid = NexaCrypto.verify(ownKeyObj, Buffer.from(canonGenesisStr, "utf8"), ownSigBytes);

                if (creatorMatches && certIdMatches && cryptoValid && ownCert.status === "ACTIVE") {
                    ownershipVerified = true;
                }
            } catch (e: any) {
                console.warn("[WARNING] Failed to verify embedded ownership certificate:", e.message);
            }
        }
```
- **Analisis Alur & Konsekuensi:**
  - Baris 240 melakukan perbandingan string hex identik: `creatorMatches = (ownCert.creator_public_key === rawCreatorPubKey)`.
  - `ownCert.creator_public_key` adalah public key pembuat Genesis Ownership Certificate (**`genesisPubKey`**).
  - Jika pemaket adalah pihak ketiga (`containerSigKey != genesisPubKey`), maka `creatorMatches` bernilai `false`, dan `ownershipVerified` gagal (`ownershipVerified = false`).
  - Baris 265–271:
    ```typescript
    // Registry Authority authentication:
    // Strictly established ONLY by:
    // 1. Authoritative online query (querySuccessful), OR
    // 2. Valid Registry Authority issuer_signature (sigValid)
    // Note: Genesis Ownership Certificate (ownershipVerified) proves creator ownership claims,
    // but does NOT substitute for Registry Authority authentication (trust boundary separation).
    if (sigValid || querySuccessful) {
        res.certificateStatus = regCert.status || "active";
        res.registryVerified = true;
    ```
  - Variabel `ownershipVerified` **sama sekali tidak disimpan ke obyek `res`**. `VerificationResult` tidak memiliki field untuk `ownershipVerified`.

---

### 2. Bukti Area 2: Struktur dan Allowlist `OwnershipDelegation`

#### Cuplikan Verbatim 2.1: `sdk/typescript/src/ownership.ts` L1–L14 (Allowlist Scope)
```typescript
import * as crypto from 'crypto';

export const ScopeMetadataUpdateClaim = 'METADATA_UPDATE_CLAIM';
export const ScopeOwnershipEvidenceSubmission = 'OWNERSHIP_EVIDENCE_SUBMISSION';
export const ScopeOwnershipHistoryAdmin = 'OWNERSHIP_HISTORY_ADMINISTRATION';

export const AllowedDelegationScopes = [
  ScopeMetadataUpdateClaim,
  ScopeOwnershipEvidenceSubmission,
  ScopeOwnershipHistoryAdmin,
];
```
- **Temuan Faktual:**
  - Scope `CONTAINER_PACKAGING` **tidak ada** dalam `AllowedDelegationScopes`.
  - Fungsi validasi baris 80–83:
    ```typescript
    export function isValidDelegationScope(scopes: string[]): boolean {
      if (!scopes || scopes.length === 0) return false;
      return scopes.every((s) => AllowedDelegationScopes.includes(s));
    }
    ```

#### Cuplikan Verbatim 2.2: `sdk/typescript/src/ownership.ts` L50–L63 (Interface Obyek Delegasi)
```typescript
export interface OwnershipDelegation {
  delegation_id: string;
  asset_id: string;
  ownership_cert_id: string;
  delegator_subject_id: string;
  delegate_subject_id: string;
  delegated_scope: string[];
  sub_delegation_allowed: boolean;
  issued_at: string;
  effective_at: string;
  expires_at?: string;
  revoked: boolean;
  delegator_signature: string;
}
```

#### Cuplikan Verbatim 2.3: `sdk/typescript/src/ownership.ts` L131–L156 (Kanonikalisasi JCS RFC 8785)
```typescript
// RFC 8785 Canonical JCS Serialization for Delegation Certificate
export function canonicalizeDelegationPayload(del: {
  asset_id: string;
  delegate_subject_id: string;
  delegated_scope: string[];
  delegator_subject_id: string;
  effective_at: string;
  expires_at?: string;
  issued_at: string;
  ownership_cert_id: string;
  sub_delegation_allowed: boolean;
}): string {
  const sortedScopes = [...del.delegated_scope].sort();
  const payload = {
    asset_id: del.asset_id,
    delegate_subject_id: del.delegate_subject_id,
    delegated_scope: sortedScopes,
    delegator_subject_id: del.delegator_subject_id,
    effective_at: del.effective_at,
    expires_at: del.expires_at || '',
    issued_at: del.issued_at,
    ownership_cert_id: del.ownership_cert_id,
    sub_delegation_allowed: del.sub_delegation_allowed,
  };
  return JSON.stringify(payload);
}
```

#### Cuplikan Verbatim 2.4: `internal/engine/ownership/delegation.go` L104–L136 (Verifikasi Kriptografi di Go)
```go
// VerifyDelegationSignature checks the delegator Ed25519 signature on an OwnershipDelegation payload against a public key.
func VerifyDelegationSignature(delegation *domain.OwnershipDelegation, delegatorPubKey ed25519.PublicKey) bool {
	if delegation == nil || len(delegatorPubKey) != ed25519.PublicKeySize {
		return false
	}

	// Enforce Closed Delegation Scope Allowlist
	if !domain.IsValidDelegationScope(delegation.DelegatedScope) {
		return false
	}

	canonicalBytes, err := CanonicalizeDelegationPayload(
		delegation.AssetID,
		delegation.OwnershipCertID,
		delegation.DelegatorSubjectID,
		delegation.DelegateSubjectID,
		delegation.DelegatedScope,
		delegation.SubDelegationAllowed,
		delegation.IssuedAt,
		delegation.EffectiveAt,
		delegation.ExpiresAt,
	)
	if err != nil {
		return false
	}

	sigBytes, err := hex.DecodeString(delegation.DelegatorSignature)
	if err != nil || len(sigBytes) != ed25519.SignatureSize {
		return false
	}

	return crypto.Verify(delegatorPubKey, canonicalBytes, sigBytes)
}
```
- **Kesenjangan Bahasa/Runtime:** Fungsi `VerifyDelegationSignature` ini **hanya ada di Go** (`internal/engine/ownership/delegation.go`). Di SDK TypeScript (`sdk/typescript/src/ownership.ts`), fungsi padanan untuk memverifikasi `delegator_signature` **tidak diimplementasikan**.

---

### 3. Bukti Area 3: Registry Trust Anchor dan Fallback

#### Cuplikan Verbatim 3.1: Hardcoded Trust Anchor pada Player Desktop (`player-desktop/main.js` L51 & L705–L735)
```javascript
const CANONICAL_REGISTRY_PUBKEY = '87b0e47c7e92d1f8f0ad4ac7b7a78bec65fbb5c9c6cb6931511db1f4274c9832';
...
        registryPubKeyStr = overrideRegKey || configRegKey || CANONICAL_REGISTRY_PUBKEY;
...
        try {
            registryPubKey = NexaCrypto.loadPublicKey(registryPubKeyStr);
        } catch (err) {
            console.warn(`[WARNING] Failed to load configured registry key (${registryPubKeyStr}), falling back to CANONICAL_REGISTRY_PUBKEY: ${err.message}`);
            try {
                registryPubKey = NexaCrypto.loadPublicKey(CANONICAL_REGISTRY_PUBKEY);
            } catch (_) {}
        }
```

#### Cuplikan Verbatim 3.2: Mobile Go C-Bindings (`sdk/c/nexa_mobile_cbindings.go` L292–L320)
```go
const NEXA_CANONICAL_REGISTRY_PUBKEY_HEX = "87b0e47c7e92d1f8f0ad4ac7b7a78bec65fbb5c9c6cb6931511db1f4274c9832"
...
	pubKeyStr := os.Getenv("NEXA_REGISTRY_PUBKEY")
	if pubKeyStr == "" {
		pubKeyStr = NEXA_CANONICAL_REGISTRY_PUBKEY_HEX
	}
```
- **Temuan Faktual:** Pinned trust anchor ini seragam di seluruh desktop, server, dan mobile core, namun merupakan kunci tunggal statis, bukan trust store yang dapat diperbarui secara dinamis.

---

### 4. Bukti Area 4: Skema Kanonikal JCS `.nxcert`

#### Cuplikan Verbatim 4.1: `sdk/typescript/src/registry.ts` L118–L123
```typescript
export function canonicalJcs(certID: string, issuedAt: string, issuer: string, status: string, validUntil: string, creatorPubKey?: string): string {
    const formattedIssued = formatJcsTimestamp(issuedAt);
    const formattedValid = formatJcsTimestamp(validUntil);
    return `{"certificate_id":${JSON.stringify(certID)},"creator_public_key":${JSON.stringify(creatorPubKey || "")},"issued_at":${JSON.stringify(formattedIssued)},"issuer":${JSON.stringify(issuer)},"status":${JSON.stringify(status)},"valid_until":${JSON.stringify(formattedValid)}}`;
}
```
- **Batasan Skema:** Tanda tangan otoritatif Registry Authority `issuer_signature` dihitung eksklusif di atas 6 field ini:
  1. `certificate_id`
  2. `creator_public_key`
  3. `issued_at`
  4. `issuer`
  5. `status`
  6. `valid_until`
  Properti lain seperti `ownership_certificate` atau calon bukti delegasi berada di luar string JCS yang ditandatangani oleh Registry.
