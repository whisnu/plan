# AUDIT-NEW-10_SOURCE_INSPECTION_REPORT.md
# LAPORAN UTAMA INSPEKSI SUMBER: AUDIT-NEW-10
## Verifikasi Three-Way Identity Binding dan Third-Party Packaging Delegation

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Waktu Inspeksi:** 10 November 2026 (Environment Linux x86_64, Node.js v22.23.4, Go 1.22.4)
- **Status Mandat:** READ-ONLY SOURCE INSPECTION & EVIDENCE COLLECTION
- **Status PE-02 Implementation:** **`NOT AUTHORIZED`**
- **Berkas Terkait dalam Paket:**
  - Laporan Utama: [`AUDIT-NEW-10_SOURCE_INSPECTION_REPORT.md`](file:///home/whisnu/.gemini/antigravity-ide/brain/5cad49dd-48b4-4d8a-b77b-1e9075154ca0/AUDIT-NEW-10_SOURCE_INSPECTION_REPORT.md)
  - Lampiran Source Evidence: [`AUDIT-NEW-10_SOURCE_EVIDENCE.md`](file:///home/whisnu/.gemini/antigravity-ide/brain/5cad49dd-48b4-4d8a-b77b-1e9075154ca0/AUDIT-NEW-10_SOURCE_EVIDENCE.md)
  - Lampiran Test Evidence: [`AUDIT-NEW-10_TEST_EVIDENCE.md`](file:///home/whisnu/.gemini/antigravity-ide/brain/5cad49dd-48b4-4d8a-b77b-1e9075154ca0/AUDIT-NEW-10_TEST_EVIDENCE.md)
  - Manifest Keterlacakan: [`AUDIT-NEW-10_INSPECTION_MANIFEST.md`](file:///home/whisnu/.gemini/antigravity-ide/brain/5cad49dd-48b4-4d8a-b77b-1e9075154ca0/AUDIT-NEW-10_INSPECTION_MANIFEST.md)

---

### 1. Ringkasan Eksekutif Hasil Inspeksi

Inspeksi terarah dilakukan pada codebase repositori `whisnu/nexa` commit `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956` untuk membuktikan fondasi teknis blueprint **Three-Way Identity Binding dan Third-Party Packaging Delegation**.

Temuan pokok hasil inspeksi:
1. **Hardcoded Equality Check Ditemukan:** Potongan kode perbandingan langsung antara public key verifier kontainer dan creator public key genesis certificate memang **benar-benar ada** pada [`sdk/typescript/src/sdk.ts:L237-L241`](file:///opt/antigravity/projects/nexa/sdk/typescript/src/sdk.ts#L237-L241).
2. **Semantik Nilai yang Dibandingkan:** Parameter `pubKey` yang dipasok ke `verifyContainer` merepresentasikan `containerSigKey` (penandatangan biner `.nx`), sedangkan `ownCert.creator_public_key` merepresentasikan `genesisPubKey` (pencipta awal aset).
3. **Konsekuensi Equality Check:** Jika `containerSigKey != genesisPubKey`, maka `creatorMatches` bernilai `false`, menyebabkan evaluasi sertifikat kepemilikan (`ownershipVerified`) bernilai `false`. Namun, pada implementasi `sdk.ts` saat ini, variabel `ownershipVerified` adalah variabel lokal yang **dibuang dan tidak diekspos** ke output `VerificationResult`. Status verifikasi akhir (`registryVerified` dan `certificateStatus`) murni ditentukan oleh tanda tangan Registry Authority.
4. **Struktur Delegasi Eksisting Tersedia:** Interface `OwnershipDelegation` dan serializer RFC 8785 JCS `canonicalizeDelegationPayload` telah diimplementasikan baik di Go (`internal/engine/ownership/delegation.go`) maupun di TypeScript (`sdk/typescript/src/ownership.ts`).
5. **Ketiadaan Scope Packaging:** Scope `CONTAINER_PACKAGING` **`NOT FOUND IN INSPECTED SCOPE`**. Allowlist scope yang ada bersifat tertutup (`Closed Sprint11DelegationScope Allowlist`), sehingga scope baru apapun saat ini langsung ditolak *fail-closed*.
6. **Ketiadaan Verifier Signature Delegasi di TypeScript:** Modul Go memiliki `VerifyDelegationSignature`, tetapi modul TypeScript SDK tidak memiliki fungsi verifikasi signature delegasi; fungsi `evaluateOwnershipEvidenceTS` hanya memfilter array delegasi tanpa memverifikasi tanda tangan delegator.
7. **Batas Registry & Sidecar `.nxcert`:** Pinned trust anchor `CANONICAL_REGISTRY_PUBKEY` terbukti di-hardcode di Desktop, Mobile C-bindings, dan Marketplace. Tanda tangan Registry Authority pada `.nxcert` hanya mencakup 6 field JCS kanonikal dan **tidak menandatangani** sertifikat delegasi pihak ketiga.

---

### 2. Hasil Pemeriksaan Lima Area

#### Area 1: Hardcoded Equality Check (`sdk/typescript/src/sdk.ts`)
- **Keberadaan Kode:** Terverifikasi pada baris 237–241:
  ```javascript
  let creatorMatches = true;
  if (pubKey) {
      const rawCreatorPubKey = NexaCrypto.getRawPublicKey(pubKey).toString("hex");
      creatorMatches = (ownCert.creator_public_key === rawCreatorPubKey);
  }
  ```
- **Alur dan Asal Input:**
  - `pubKey` berasal dari argumen kedua fungsi publik `verifyContainer(nxPath, pubKey, ...)`. Di baris 143, kunci ini digunakan untuk memvalidasi tanda tangan biner manifest kontainer `.nx`: `NexaCrypto.verify(pubKey, container.manifestBytes, container.signatureBytes)`. Dengan demikian, `pubKey` secara faktual merepresentasikan **`containerSigKey`**.
  - `ownCert` diekstrak dari properti `ownership_certificate` pada sidecar `.nxcert` (baris 234). Properti `creator_public_key` adalah kunci yang menandatangani Genesis Ownership Certificate, sehingga merepresentasikan **`genesisPubKey`**.
- **Konsekuensi Jika `creatorMatches === false`:**
  - Blok baris 257–259: `if (creatorMatches && certIdMatches && cryptoValid && ownCert.status === "ACTIVE") { ownershipVerified = true; }`.
  - Jika `creatorMatches` bernilai `false`, `ownershipVerified` tetap `false`.
  - Namun, variabel `ownershipVerified` **tidak disimpan ke dalam obyek `res: VerificationResult`** (lihat baris 154–165). Hasil akhir `res.registryVerified` dan `res.certificateStatus` tidak dipengaruhi oleh `ownershipVerified`, melainkan murni oleh validitas tanda tangan Registry Authority (`sigValid || querySuccessful`).
- **Jalur Delegasi Alternatif:** **TIDAK ADA**. Tidak ada percabangan kode untuk memverifikasi delegasi jika `creatorMatches === false`.
- **Pemisahan Evaluasi:** Source saat ini memisahkan `signatureValid` (integritas biner kontainer) dan `registryVerified` (autentikasi Registry), namun tidak memiliki field terpisah untuk `packagingAuthorityValid` maupun `ownershipEvidenceState`.

#### Area 2: Struktur dan Penggunaan `OwnershipDelegation` (`sdk/typescript/src/ownership.ts`)
- **Struktur Data:** Terverifikasi pada `ownership.ts:L50-L63`. Field mencakup: `delegation_id`, `asset_id`, `ownership_cert_id`, `delegator_subject_id`, `delegate_subject_id`, `delegated_scope`, `sub_delegation_allowed`, `issued_at`, `effective_at`, `expires_at`, `revoked`, `delegator_signature`.
- **Kanonikalisasi & Paritas:** Terverifikasi pada `ownership.ts:L131-L156` dan `internal/engine/ownership/delegation.go:L28-L52`. Menggunakan RFC 8785 JCS dengan pengurutan leksikografis 9 key dan pengurutan internal array `delegated_scope`. Uji paritas Go vs TypeScript terbukti lulus pada `ownership_parity.test.js` (Test 2).
- **Allowlist Scope Tertutup:**
  - Konstanta yang diizinkan hanya 3: `METADATA_UPDATE_CLAIM`, `OWNERSHIP_EVIDENCE_SUBMISSION`, dan `OWNERSHIP_HISTORY_ADMINISTRATION`.
  - Scope `CONTAINER_PACKAGING`: **`NOT FOUND IN INSPECTED SCOPE`**.
  - Logika penolakan: `isValidDelegationScope` mengembalikan `false` untuk scope di luar daftar tersebut.
- **Fungsi Penelusuran Kepemilikan (`evaluateOwnershipEvidenceTS` L282–L343):**
  - Mengidentifikasi kreator via `genesisCert.subject_id` dan `verifyGenesisCertificate`.
  - Menelusuri transfer melalui perulangan `transfers`, memverifikasi kontinuitas `transferor_subject_id == currentOwner`.
  - Delegasi hanya difilter status revoked dan validitas scope; fungsi ini **tidak memverifikasi tanda tangan delegasi** (`delegator_signature`) dan **tidak mengevaluasi izin packaging pihak ketiga**.

#### Area 3: Registry dan Trust Resolution (`sdk/typescript/src/registry.ts`)
- **`NexaRegistryClient`:** Terverifikasi pada `registry.ts:L23-L103`. Menyediakan endpoint REST query sertifikat, batch refresh, dan pendaftaran sertifikat.
- **`CANONICAL_REGISTRY_PUBKEY`:**
  - Bernilai `'87b0e47c7e92d1f8f0ad4ac7b7a78bec65fbb5c9c6cb6931511db1f4274c9832'`.
  - Ditemukan ter-hardcode sebagai fallback trust anchor tunggal pada `player-desktop/main.js:L51`, `verify-desktop/main.js:L33`, `marketplace/server.js:L557`, dan `sdk/c/nexa_mobile_cbindings.go:L292`.
  - Bukan trust store dinamis; saat ini bertindak sebagai satu-satunya *global fallback trust anchor*.
- **Multi-Registry & Federation:** Algoritma konsensus multi-registry ada di level model data (`internal/engine/ownership/history.go` dan `federation_parity.test.js`), tetapi verifier desktop dan mobile hanya mendukung konfigurasi satu URL/kunci registri aktif pada satu waktu.
- **Attestation Packaging:** Registry `RegistryCert` saat ini **tidak memiliki field** untuk mengesahkan packaging agent pihak ketiga.
- **Verifikasi Offline:** Mengandalkan sidecar `.nxcert` yang ditandatangani `CANONICAL_REGISTRY_PUBKEY`. Jika offline, pencabutan (*revocation*) tidak dapat diperbarui secara dinamis tanpa koneksi online untuk batch refresh.

#### Area 4: Schema dan Siklus Hidup `.nxcert`
- **Otoritas Penerbitan:** Berdasarkan keputusan governance Sprint 16 (`DEC-16-CPD-01`, `S16-ACC-005`), Registry (`cmd/registry`) adalah satu-satunya entitas yang berwenang menerbitkan/memfinalisasi `.nxcert`.
- **Cakupan Tanda Tangan Registry:** Format JCS kanonikal yang ditandatangani Registry (`NexaRegistry.canonicalJcs`) hanya mencakup 6 field: `certificate_id`, `issued_at`, `issuer`, `status`, `valid_until`, dan `creator_public_key`.
- **Sertifikat Kepemilikan Tertanam:** Properti `ownership_certificate` di dalam `.nxcert` tidak tercakup dalam payload tanda tangan Registry; validitasnya bergantung pada tanda tangan mandiri kreator (`ownCert.creator_signature`).
- **Kelayakan Penempatan Bukti Delegasi:** Menempatkan sertifikat delegasi di dalam `.nxcert` tanpa pengesahan skema berisiko:
  1. Melanggar prinsip penolakan *unknown fields* (AC-01) jika skema `.nxcert` tertutup;
  2. Tidak memiliki perlindungan tanda tangan Registry jika hanya disisipkan sebagai metadata ad-hoc.

#### Area 5: Pemetaan Cakupan Pengujian (Test Coverage)
- 6 test suite kunci dijalankan secara nyata dan menghasilkan exit code 0:
  - `sdk/typescript/test/ownership_parity.test.js` (5/5 PASS)
  - `sdk/typescript/test/registry_identity.test.js` (8/8 PASS)
  - `sdk/typescript/test/federation_parity.test.js` (5/5 PASS)
  - `test/task_a_final_trust_boundary_test.js` (2/2 PASS)
  - `test/pe01_tampered_sidecar_test.js` (6/6 PASS)
  - `go test ./internal/engine/ownership` (11/11 PASS)
- **Gap Pengujian Kritis yang Ditemukan:**
  - Test perbedaan `containerSigKey` vs `genesisPubKey`: **`NOT FOUND IN INSPECTED SCOPE`**.
  - Test validasi delegasi pihak ketiga untuk packaging: **`NOT FOUND IN INSPECTED SCOPE`**.
  - Test scope `CONTAINER_PACKAGING`: **`NOT FOUND IN INSPECTED SCOPE`**.

---

### 3. Evaluasi Komponen Blueprint

| Komponen | Status Klasifikasi | Dasar Bukti & Pembatasan |
|---|---|---|
| **Three-Way Identity** | `PARTIALLY VERIFIED` | Tiga entitas kunci ada dalam model (`pubKey` di SDK, `creator_public_key` di Genesis, `currentHolder` di Ownership), tetapi SDK saat ini memaksakan kesamaan via hardcoded equality check di L240. |
| **Self-Packaging by Creator** | `VERIFIED EXISTING` | Didukung penuh saat ini; jika `pubKey === ownCert.creator_public_key`, validasi integritas dan matching creator terpenuhi. |
| **Third-Party Packaging Delegation** | `NOT FOUND IN INSPECTED SCOPE` | Tidak ada logika verifikasi otorisasi packaging pihak ketiga di SDK maupun runtime. |
| **CONTAINER_PACKAGING Scope** | `NOT FOUND IN INSPECTED SCOPE` | Allowlist scope tertutup pada Go dan TypeScript hanya mengenal 3 scope Sprint 11; scope packaging belum ada. |
| **OwnershipDelegation Data Model** | `VERIFIED EXISTING` | Skema struct Go dan interface TypeScript sudah lengkap dengan 11 field dan RFC 8785 JCS canonicalization. |
| **OwnershipDelegation Verification in TS** | `PARTIALLY VERIFIED` | Serializer JCS dan filter allowlist ada di TypeScript, namun fungsi kriptografi `VerifyDelegationSignature` hanya ada di modul Go. |
| **Penempatan Delegasi di `.nxcert`** | `REQUIRES ARCHITECTURE DECISION` | Skema JCS kanonikal `.nxcert` saat ini hanya mencakup 6 field; penempatan delegasi di `.nxcert` memerlukan keputusan format dan trust boundary dari Architecture Authority. |
| **Revokasi dan Offline Trust** | `PARTIALLY VERIFIED` | Field `revoked` ada pada struct delegasi, namun verifikasi offline tidak dapat mendeteksi revokasi baru tanpa online refresh. |
| **Registry Attestation Packaging** | `REQUIRES ARCHITECTURE DECISION` | Registry saat ini hanya mencatat identitas kontainer dan kreator; belum mendukung pencatatan agen packaging resmi. |
| **Pemisahan Hasil Verifier** | `REQUIRES ARCHITECTURE DECISION` | SDK saat ini memisahkan `signatureValid` dan `registryVerified`, tetapi tidak mengekspos `ownershipVerified` dan belum memiliki field `packagingAuthorityValid`. |

---

### 4. Pemetaan Empat Kontrak Architecture Authority

#### 4.1 Delegation Authority Contract (Status: `OPEN`)
- **Fakta Source:** Pada struct `OwnershipDelegation`, terdapat field `delegator_subject_id` dan `sub_delegation_allowed`.
- **Gap Arsitektur:** Source belum menetapkan:
  - Apakah hanya `genesisPubKey` (kreator asli) yang berhak memberikan delegasi packaging, ataukah pemilik saat ini (`ownCertPubKey`) juga berhak?
  - Apakah `sub_delegation_allowed: true` berlaku untuk packaging (misal: label mendelegasikan lagi ke sub-kontraktor studio)?
  - Bagaimana relasi antara subject ID (DID) dan public key pembuktian dipetakan secara otoritatif?

#### 4.2 Delegation Evidence Contract (Status: `OPEN`)
- **Fakta Source:** JCS canonicalization `canonicalizeDelegationPayload` telah tersedia secara deterministik di Go dan TS.
- **Gap Arsitektur:** Source belum menetapkan:
  - Di mana berkas bukti delegasi disimpan: apakah disematkan di dalam `.nxcert`, disertakan sebagai sidecar baru (misal `.nxdel`), atau disematkan di header manifest kontainer `.nx`?
  - Format taksonomi error code jika delegasi kedaluwarsa atau scope tidak cocok.
  - Bagaimana verifier TypeScript mengimplementasikan fungsi verifikasi signature delegasi yang setara dengan Go engine.

#### 4.3 Trust Resolution Contract (Status: `OPEN`)
- **Fakta Source:** `CANONICAL_REGISTRY_PUBKEY` saat ini bertindak sebagai trust anchor tunggal yang di-pin pada runtime.
- **Gap Arsitektur:** Source belum menetapkan:
  - Mekanisme trust store multi-kunci atau rotasi kunci jika `CANONICAL_REGISTRY_PUBKEY` dikompromikan.
  - Bagaimana resolusi kepercayaan bekerja jika studio packaging diotentikasi via Registry federation alih-alih delegasi langsung dari kreator.
  - Kebijakan batas waktu cache (*cache freshness*) untuk status delegasi dan sertifikat saat beroperasi offline.

#### 4.4 Verifier Result Contract (Status: `OPEN`)
- **Fakta Source:** `VerificationResult` pada `sdk.ts` hanya memuat: `signatureValid`, `hashValid`, `manifest`, `manifestBytes`, `sha256Hash`, `payload`, `certificateID`, `certificateStatus`, `registryVerified`, `registryError`, `certificate`.
- **Gap Arsitektur:** Source belum menetapkan:
  - Penambahan field diskrit `packagingAuthorityValid: boolean`.
  - Penambahan field diskrit `authorityModel: 'SELF_PACKAGED' | 'DELEGATED' | 'UNAUTHORIZED'`.
  - Eksposisi field `ownershipEvidenceState: 'VERIFIED' | 'ABSENT' | 'INVALID'` ke hasil verifikasi publik.
  - Perlakuan Player dan Verify terhadap kontainer yang `signatureValid === true` tetapi `packagingAuthorityValid === false`.

---

### 5. Disposisi Akhir Programmer

Sesuai format disposisi wajib pada Bagian 13 handoff:

| Item | Status | Keterangan |
|---|---|---|
| **Repository access** | **`VERIFIED`** | Akses read-only lokal pada `/opt/antigravity/projects/nexa/` terkonfirmasi penuh. |
| **Source inspection** | **`COMPLETE`** | Kelima area inspeksi telah diperiksa secara tuntas pada commit `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`. |
| **Existing blueprint foundation** | **`PARTIALLY VERIFIED`** | Primitif JCS dan interface data delegasi ada; equality check membatasi pemisahan peran; scope dan verifier TS belum lengkap. |
| **Delegation Authority Contract** | **`OPEN`** | Menunggu penetapan Architecture Authority terkait hierarki delegator dan sub-delegasi. |
| **Delegation Evidence Contract** | **`OPEN`** | Menunggu penetapan Architecture Authority terkait lokasi fisik bukti dan taksonomi error. |
| **Trust Resolution Contract** | **`OPEN`** | Menunggu penetapan Architecture Authority terkait trust store dan resolusi attestation. |
| **Verifier Result Contract** | **`OPEN`** | Menunggu penetapan Architecture Authority terkait pemisahan field status pada output verifier. |
| **Source modification** | **`NONE`** | Zero files modified pada source tree `whisnu/nexa`. |
| **Schema modification** | **`NONE`** | Zero schema/DDL modified. |
| **Test modification** | **`NONE`** | Zero test files created or modified. |
| **PLAN modification** | **`NONE`** | File PLAN kanonikal tidak disentuh/tidak diubah dalam mandat ini. |
| **PE-02 Implementation** | **`NOT AUTHORIZED`** | Gate A dan Gate B tetap mengunci; tidak ada otorisasi implementasi. |
