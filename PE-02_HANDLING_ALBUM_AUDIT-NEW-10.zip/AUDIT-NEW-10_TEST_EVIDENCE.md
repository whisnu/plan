# AUDIT-NEW-10_TEST_EVIDENCE.md
# LAMPIRAN BUKTI PENGUJIAN (TEST EVIDENCE)
## AUDIT-NEW-10 — Three-Way Identity Binding dan Third-Party Packaging Delegation

- **Repository:** `whisnu/nexa`
- **Branch:** `main`
- **Commit SHA:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`
- **Tanggal Eksekusi:** 10 November 2026

---

### 1. Matriks Eksekusi Test Suite Aktual

Pemeriksaan empiris dijalankan secara nyata pada lingkungan Node.js v22.23.4 dan Go 1.22.4:

| No | Path File Test | Perintah Eksekusi | Kategori | Hasil Aktual | Exit Code |
|---|---|---|---|---|---|
| 1 | `sdk/typescript/test/ownership_parity.test.js` | `node sdk/typescript/test/ownership_parity.test.js` | Direct Unit Test | **`PASS (5/5 Scenarios)`** | `0` |
| 2 | `sdk/typescript/test/registry_identity.test.js` | `node sdk/typescript/test/registry_identity.test.js` | Direct Unit Test | **`PASS (8/8 Scenarios)`** | `0` |
| 3 | `sdk/typescript/test/federation_parity.test.js` | `node sdk/typescript/test/federation_parity.test.js` | Direct Unit Test | **`PASS (5/5 Scenarios)`** | `0` |
| 4 | `internal/engine/ownership/ownership_test.go` | `go test -v -count=1 ./internal/engine/ownership/` | Direct Unit Test | **`PASS (11/11 Scenarios)`** | `0` |
| 5 | `test/task_a_final_trust_boundary_test.js` | `node test/task_a_final_trust_boundary_test.js` | Integration Test | **`PASS (2/2 Scenarios)`** | `0` |
| 6 | `test/pe01_tampered_sidecar_test.js` | `node test/pe01_tampered_sidecar_test.js` | Integration Test | **`PASS (6/6 Gates)`** | `0` |

---

### 2. Rincian Skenario, Baris, Assertion, dan Raw Output

#### Test 1: `sdk/typescript/test/ownership_parity.test.js`
- **Baris & Skenario:**
  - L18–L24: Test 1: Closed Delegation Scope Allowlist
  - L27–L51: Test 2: Canonical JCS Key Ordering Parity
  - L53–L72: Test 3: Legacy Asset Evaluation
  - L74–L83: Test 4: Invalid Genesis Certificate Signature Rejection
  - L85–L99: Test 5: OWN-TRANSFER-02 Unauthorized Transfer Rejection (TS)
- **Assertion Kunci:**
  - `assert.strictEqual(isValidDelegationScope([ScopeMetadataUpdateClaim]), true);`
  - `assert.strictEqual(isValidDelegationScope(['COMMERCIAL_ROYALTY']), false);`
  - `assert.strictEqual(isValidDelegationScope(['DRM_PLAYBACK']), false);`
  - `assert.strictEqual(isValidDelegationScope([]), false);`
- **Raw Output:**
  ```text
  --- Starting TypeScript Ownership Parity & Security Tests ---
  Test 1: Closed Delegation Scope Allowlist
  ✓ Test 1 Passed
  Test 2: Canonical JCS Key Ordering Parity
  ✓ Test 2 Passed
  Test 3: Legacy Asset Evaluation
  ✓ Test 3 Passed
  Test 4: Invalid Genesis Certificate Signature Rejection
  ✓ Test 4 Passed
  Test 5: OWN-TRANSFER-02 Unauthorized Transfer Rejection (TS)
  ✓ Test 5 Passed
  === All TypeScript Ownership Parity & Security Tests PASSED cleanly! ===
  ```

#### Test 2: `internal/engine/ownership/ownership_test.go`
- **Baris & Skenario:**
  - L120–L145: `OWN-DELEGATION-01_And_04_ClosedScopeAllowlist`
  - L198–L216: `OWN-TRANSFER-02_UnauthorizedTransferRejection`
- **Assertion Kunci:**
  - L133: `if !ownership.VerifyDelegationSignature(delValid, pubKeyA) { t.Fatalf("VerifyDelegationSignature failed") }`
  - L142: `if err != domain.ErrDelegationScopeInvalid { t.Fatalf("expected ErrDelegationScopeInvalid for commercial scope, got %v", err) }`
- **Raw Output:**
  ```text
  === RUN   TestGoldenOwnershipScenarios
  === RUN   TestGoldenOwnershipScenarios/OWN-CERT-01_And_02_ValidGenesisCertificate
  === RUN   TestGoldenOwnershipScenarios/OWN-CERT-05_InvalidCreatorSignatureRejection
  === RUN   TestGoldenOwnershipScenarios/OWN-TRANSFER-01_ValidUnilateralTransfer
  === RUN   TestGoldenOwnershipScenarios/OWN-HISTORY-01_SequentialLineageEvaluation
  === RUN   TestGoldenOwnershipScenarios/OWN-DELEGATION-01_And_04_ClosedScopeAllowlist
  === RUN   TestGoldenOwnershipScenarios/OWN-CONFLICT-01_MultiBranchConflictPreservation
  === RUN   TestGoldenOwnershipScenarios/OWN-COMPAT-01_LegacyAssetBackwardCompatibility
  === RUN   TestGoldenOwnershipScenarios/OWN-SECURITY-01_ReplayProtection
  === RUN   TestGoldenOwnershipScenarios/OWN-TRANSFER-02_UnauthorizedTransferRejection
  === RUN   TestGoldenOwnershipScenarios/OWN-FEDERATION-01A_MultiRegistryConsistentEvidence
  === RUN   TestGoldenOwnershipScenarios/OWN-FEDERATION-01B_MultiRegistryContradictoryValidEvidence
  --- PASS: TestGoldenOwnershipScenarios (0.01s)
  PASS
  ok      nexa/internal/engine/ownership  0.009s
  ```

#### Test 3: `test/task_a_final_trust_boundary_test.js`
- **Baris & Skenario:**
  - L90–L107: `[TEST CASE A]` Valid Registry Authority issuer_signature + Registry Offline
  - L109–L178: `[TEST CASE B]` Valid Creator Self-Signed Genesis Ownership + NO Registry Authority Signature
- **Assertion Kunci:**
  - L102–L105:
    `assert.strictEqual(resA.signatureValid, true);`
    `assert.strictEqual(resA.hashValid, true);`
    `assert.strictEqual(resA.certificateStatus, "active");`
    `assert.strictEqual(resA.registryVerified, true);`
  - L171–L174:
    `assert.strictEqual(resB.signatureValid, true);`
    `assert.strictEqual(resB.hashValid, true);`
    `assert.strictEqual(resB.certificateStatus, "unknown");`
    `assert.strictEqual(resB.registryVerified, false);`
- **Temuan Uji Trust Boundary:** Skenario B membuktikan bahwa validitas tanda tangan Genesis Certificate **secara sengaja tidak memberikan status TRUSTED** pada verifier jika tidak disertai tanda tangan Registry Authority.

---

### 3. Pemetaan Area Uji yang TIDAK DITEMUKAN (Test Gaps)

Berdasarkan pencarian menyeluruh pada `test/`, `tests/`, `sdk/typescript/test/`, `player-desktop/test/`, dan `verify-desktop/test/`:

1. **Uji Perbedaan `containerSigKey` dan `genesisPubKey`:**  
   **`NOT FOUND IN INSPECTED SCOPE`**. Seluruh test yang memanggil `NexaSdk.verifyContainer` (`pe01_hidden_sidecar_test.js`, `task_a_buyer_lifecycle_test.js`, `task_a_final_trust_boundary_test.js`) selalu memasok `pubKey` yang identik dengan creator public key. Tidak ada test yang memasok `pubKey` pihak ketiga (misalnya kunci Studio) untuk melihat respons sistem.
2. **Uji Delegasi Pengemasan Pihak Ketiga (*Third-Party Packaging Delegation*):**  
   **`NOT FOUND IN INSPECTED SCOPE`**. Tidak ada satu pun test di seluruh codebase yang menguji pemberian delegasi pengemasan atau validasi mandat pengemasan.
3. **Uji Scope `CONTAINER_PACKAGING`:**  
   **`NOT FOUND IN INSPECTED SCOPE`**. Scope ini belum didefinisikan dalam kode maupun test fixture.
4. **Uji Verifikasi Kriptografi Delegasi pada TypeScript:**  
   **`NOT FOUND IN INSPECTED SCOPE`**. Modul pengujian TypeScript hanya menguji pengurutan payload JCS dan filter allowlist string, tanpa memverifikasi Ed25519 signature delegator.
