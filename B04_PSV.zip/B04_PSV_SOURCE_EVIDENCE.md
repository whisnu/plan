# B04_PSV_SOURCE_EVIDENCE.md
## Bukti Primer Kode Sumber (PSV B-04)

**Repository:** `whisnu/nexa`  
**Commit:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`  
**Cakupan Area:** A sampai G (Model Data, Batas Transaksi, Idempotensi, Payment Gateway, License Daemon, Failure/Recovery, Settlement/Accounting)

---

### Area A: Model Data dan DDL Transaksi

#### Bukti A-01: Skema Tabel `acquisitions` (PostgreSQL)
- **Path:** `marketplace/db/schema.postgres.sql`
- **Baris:** 63–75
```sql
CREATE TABLE IF NOT EXISTS acquisitions (
    acquisition_id VARCHAR(128) PRIMARY KEY,
    asset_id VARCHAR(128) NOT NULL REFERENCES catalog_snapshots(asset_id),
    buyer_id VARCHAR(128) NOT NULL,
    price_amount BIGINT NOT NULL CHECK (price_amount >= 0),
    currency VARCHAR(16) NOT NULL DEFAULT 'IDR',
    provider_id VARCHAR(64) NOT NULL,
    state VARCHAR(64) NOT NULL DEFAULT 'ACQUISITION_CREATED',
    acquired_storage_object_id VARCHAR(128),
    acquired_package_sha256 VARCHAR(64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

#### Bukti A-02: Skema Tabel `entitlements` dan Constraint `UNIQUE` (PostgreSQL)
- **Path:** `marketplace/db/schema.postgres.sql`
- **Baris:** 107–114, 131–135
```sql
CREATE TABLE IF NOT EXISTS entitlements (
    entitlement_id VARCHAR(128) PRIMARY KEY,
    acquisition_id VARCHAR(128) NOT NULL UNIQUE REFERENCES acquisitions(acquisition_id),
    license_key VARCHAR(255) NOT NULL UNIQUE,
    acquired_storage_object_id VARCHAR(128),
    acquired_package_sha256 VARCHAR(64),
    issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Schema Alterations (Lines 131-135)
ALTER TABLE entitlements ADD COLUMN IF NOT EXISTS acquired_storage_object_id VARCHAR(128);
ALTER TABLE entitlements ADD COLUMN IF NOT EXISTS acquired_package_sha256 VARCHAR(64);
ALTER TABLE entitlements ADD COLUMN IF NOT EXISTS asset_id VARCHAR(128);
ALTER TABLE entitlements ADD COLUMN IF NOT EXISTS buyer_id VARCHAR(128);
```

#### Bukti A-03: Skema Tabel `payment_orders` (PostgreSQL)
- **Path:** `marketplace/db/schema.postgres.sql`
- **Baris:** 77–85
```sql
CREATE TABLE IF NOT EXISTS payment_orders (
    order_id VARCHAR(128) PRIMARY KEY,
    acquisition_id VARCHAR(128) NOT NULL REFERENCES acquisitions(acquisition_id),
    payment_config_snapshot JSONB NOT NULL,
    provider_snapshot VARCHAR(64) NOT NULL,
    price_snapshot BIGINT NOT NULL CHECK (price_snapshot >= 0),
    state VARCHAR(64) NOT NULL DEFAULT 'PAYMENT_PENDING',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

#### Bukti A-04: Skema Tabel `payment_proofs` (PostgreSQL)
- **Path:** `marketplace/db/schema.postgres.sql`
- **Baris:** 87–95
```sql
CREATE TABLE IF NOT EXISTS payment_proofs (
    proof_id VARCHAR(128) PRIMARY KEY,
    order_id VARCHAR(128) NOT NULL REFERENCES payment_orders(order_id),
    proof_digest VARCHAR(128) NOT NULL UNIQUE,
    proof_path TEXT NOT NULL,
    uploader_id VARCHAR(128) NOT NULL,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(64) NOT NULL DEFAULT 'PAYMENT_PENDING_VERIFICATION'
);
```

---

### Area B: Batas Transaksi Database dan Konsistensi Penulisan

#### Bukti B-01: Wrapper Transaksi PostgreSQL `withTransaction`
- **Path:** `marketplace/db/store.js`
- **Baris:** 89–103
```javascript
async function withTransaction(callback) {
  if (!poolInstance) throw new Error('PostgreSQL pool not initialized');
  const client = await poolInstance.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}
```

#### Bukti B-02: Transaksi Pembuatan Order & Akuisisi (`POST /api/acquisitions`)
- **Path:** `marketplace/server.js`
- **Baris:** 3578–3602
```javascript
    // ONE ATOMIC PostgreSQL TRANSACTION:
    // Create acquisition + payment order + payment proof together.
    // If any step fails, ROLLBACK ensures 0 acquisitions, 0 orders, 0 proofs.
    await store.withTransaction(async (client) => {
      // 1. Create acquisition
      await client.query(
        `INSERT INTO acquisitions (acquisition_id, asset_id, buyer_id, price_amount, currency, provider_id, state, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8)`,
        [acqId, asset_id, buyer_id, catalogItem.price, catalogItem.currency, requestedProviderId, targetState, now]
      );

      // 2. Create payment order with payment_method and authoritative payment_config_snapshot
      await client.query(
        `INSERT INTO payment_orders (order_id, acquisition_id, payment_config_snapshot, provider_snapshot, price_snapshot, state, payment_method, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [orderId, acqId, bankSnapshot, requestedProviderId, catalogItem.price, targetState, chosenMethod, now]
      );

      // 3. Create payment proof (mandatory proof guaranteed present)
      await client.query(
        `INSERT INTO payment_proofs (proof_id, order_id, proof_digest, proof_path, uploader_id, uploaded_at, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'PAYMENT_PENDING_VERIFICATION')`,
        [proofId, orderId, finalDigest, finalProofPath, buyer_id, now]
      );
    });
```

#### Bukti B-03: Transaksi Persetujuan Admin & Penerbitan Entitlement (`POST /api/orders/:id/admin/approve`)
- **Path:** `marketplace/server.js`
- **Baris:** 3794–3870
```javascript
    const resultData = await store.withTransaction(async (client) => {
      // 1. Lock payment order row for UPDATE
      const orderRes = await client.query('SELECT * FROM payment_orders WHERE order_id = $1 FOR UPDATE', [orderId]);
      const order = orderRes.rows[0];
      if (!order) {
        const err = new Error('Order not found');
        err.status = 404;
        throw err;
      }

      if (order.state === 'PAYMENT_VERIFIED' || order.state === 'ACQUISITION_COMPLETED') {
        const err = new Error('Order is already approved (Concurrent approval blocked)');
        err.status = 409;
        throw err;
      }

      // ... [validasi state] ...

      const now = new Date().toISOString();
      const decisionId = `DEC-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
      const entitlementId = `ENT-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
      
      // Authoritative Sprint-12 licensing service invocation
      const acqRes = await client.query('SELECT * FROM acquisitions WHERE acquisition_id = $1', [order.acquisition_id]);
      const acqRow = acqRes.rows[0] || {};
      // Authoritative Sprint-12 licensing service invocation (Fail-closed: NO local deterministic generator fallback!)
      const licenseKey = await invokeSprint12LicensingAuthority(order.acquisition_id, acqRow.asset_id, acqRow.buyer_id);

      // Retrieve bound catalog storage object and package hash
      const catRes = await client.query('SELECT storage_object_id, package_sha256 FROM catalog_snapshots WHERE asset_id = $1', [acqRow.asset_id]);
      const catRow = catRes.rows[0] || {};
      const storageObjectId = catRow.storage_object_id || null;
      const packageSha256 = catRow.package_sha256 || null;

      // 2. Audit decision
      await client.query(
        `INSERT INTO admin_decisions (decision_id, order_id, decision_actor, previous_state, new_state, decision_timestamp, notes)
         VALUES ($1, $2, $3, $4, 'PAYMENT_VERIFIED', $5, $6)`,
        [decisionId, orderId, decision_actor || req.adminUser.email, order.state, now, notes || 'Approved bank transfer']
      );

      // 3. Update order, acquisition, and proof status
      await client.query(`UPDATE payment_orders SET state = 'PAYMENT_VERIFIED' WHERE order_id = $1`, [orderId]);
      await client.query(`UPDATE acquisitions SET state = 'ACQUISITION_COMPLETED', acquired_storage_object_id = $1, acquired_package_sha256 = $2, updated_at = $3 WHERE acquisition_id = $4`, [storageObjectId, packageSha256, now, order.acquisition_id]);
      await client.query(`UPDATE payment_proofs SET status = 'VERIFIED' WHERE order_id = $1 AND status = 'PAYMENT_PENDING_VERIFICATION'`, [orderId]);

      // 4. Issue entitlement atomically inside PostgreSQL transaction
      await client.query(
        `INSERT INTO entitlements (entitlement_id, acquisition_id, license_key, acquired_storage_object_id, acquired_package_sha256, asset_id, buyer_id, issued_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [entitlementId, order.acquisition_id, licenseKey, storageObjectId, packageSha256, acqRow.asset_id, acqRow.buyer_id, now]
      );

      return {
        order_id: orderId,
        acquisition_id: order.acquisition_id,
        state: 'ACQUISITION_COMPLETED',
        license_key: licenseKey,
        entitlement_id: entitlementId
      };
    });
```

---

### Area C: Idempotency dan Duplicate Request

#### Bukti C-01: Pengecekan Replay Bukti Transfer (`proof_digest`)
- **Path:** `marketplace/server.js`
- **Baris:** 3559–3574
```javascript
    // Check proof replay attack across completed orders
    if (finalDigest) {
      const replayCheck = await store.getQuery(
        `SELECT pp.* FROM payment_proofs pp
         JOIN payment_orders po ON pp.order_id = po.order_id
         WHERE pp.proof_digest = ? AND (po.state = 'PAYMENT_VERIFIED' OR po.state = 'ACQUISITION_COMPLETED')`,
        [finalDigest]
      );
      if (replayCheck) {
        return res.status(403).json({
          success: false,
          error: 'ERR_PROOF_REPLAY',
          message: 'Proof replay attack detected. Proof digest already used on a completed order.'
        });
      }
    }
```

#### Bukti C-02: Pembuatan Identifier Acak Non-Deterministik Tanpa Idempotency Key
- **Path:** `marketplace/server.js`
- **Baris:** 3485–3488
```javascript
    const acqId = `ACQ-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    const orderId = `ORD-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    const proofId = `PRF-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
```

---

### Area D: Integrasi Payment Gateway

#### Bukti D-01: Metode Pembayaran Terbatas pada Transfer Manual Offline (QRIS & Bank Transfer)
- **Path:** `marketplace/server.js`
- **Baris:** 3442–3450
```javascript
    // Validate payment_method
    const chosenMethod = (payment_method || 'BANK_TRANSFER').toString().toUpperCase().trim();
    if (!['QRIS', 'BANK_TRANSFER'].includes(chosenMethod)) {
      return res.status(400).json({
        success: false,
        error: 'ERR_INVALID_PAYMENT_METHOD',
        message: 'Invalid payment method. Allowed values: QRIS, BANK_TRANSFER'
      });
    }
```

#### Bukti D-02: Penolakan Konfigurasi Pembayaran Klien (Server Authoritative)
- **Path:** `marketplace/server.js`
- **Baris:** 3452–3459
```javascript
    // Reject caller-supplied custom bank configuration
    if (bank_config) {
      return res.status(400).json({
        success: false,
        error: 'ERR_UNTRUSTED_PAYMENT_CONFIG',
        message: 'Caller-supplied payment provider configuration is rejected. Payment configurations are exclusively server-authoritative.'
      });
    }
```

---

### Area E: License Daemon dan Penerbitan Entitlement

#### Bukti E-01: Rangkaian 3-Tahap Pemanggilan Sprint-12 License Daemon
- **Path:** `marketplace/server.js`
- **Baris:** 201–210 (Stage 1: Prepare), 271–276 (Stage 2: Sign), 295–302 (Stage 3: Submit)
```javascript
  // Stage 1: Prepare payload conformant to Sprint-12 PrepareGrantRequest
  const preparePayload = JSON.stringify({
    asset_id: canonicalAssetId,
    licensee_subject_id: buyerId || 'BUYER-S12',
    licensor_subject_id: licensorSubject,
    grant_subject_id: buyerId || 'BUYER-S12',
    rights: ['USAGE_RIGHT_EXECUTE', 'PLAY'],
    issuer: 'AUTHORITATIVE_SPRINT12_LICENSING_SERVICE',
    constraints: {}
  });

  // Stage 2: Sign - Request authoritative signature from Sprint-12 authority
  const signPayload = JSON.stringify({
    prepare_id: prepareId,
    exact_canonical_bytes: exactCanonicalBytes
  });

  // Stage 3: Submit - Commit signed grant to authoritative Sprint-12 service
  const submitPayload = JSON.stringify({
    prepare_id: prepareId,
    licensor_signature: signature,
    licensor_public_key: licensorPublicKey,
    authority_evidence: signData.authority_evidence || 'sprint12_authority_signature'
  });
```

#### Bukti E-02: Timeout dan Penanganan Kegagalan Koneksi HTTP Daemon
- **Path:** `marketplace/server.js`
- **Baris:** 229–230
```javascript
      req.on('error', (err) => reject(new Error(`ERR_LICENSING_AUTHORITY_UNAVAILABLE: Connection failed: ${err.message}`)));
      req.on('timeout', () => { req.destroy(); reject(new Error('ERR_LICENSING_AUTHORITY_UNAVAILABLE: Licensing service timeout')); });
```

---

### Area F: Retry, Partial Failure, dan Recovery

#### Bukti F-01: Penulisan Disk Spool di Luar Batas Transaksi PostgreSQL
- **Path:** `marketplace/server.js`
- **Baris:** 3545–3549
```javascript
          const buffer = Buffer.from(matches[2], 'base64');
          const storedFilename = `proof_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
          const proofDiskPath = path.join(SPOOL_DIR, storedFilename);
          fs.writeFileSync(proofDiskPath, buffer);
          finalProofPath = `/data/spools/${storedFilename}`;
```

#### Bukti F-02: Pencegahan Race Condition Persetujuan Bersamaan via `SELECT FOR UPDATE`
- **Path:** `marketplace/server.js`
- **Baris:** 3796, 3804–3808
```javascript
      // 1. Lock payment order row for UPDATE
      const orderRes = await client.query('SELECT * FROM payment_orders WHERE order_id = $1 FOR UPDATE', [orderId]);
      const order = orderRes.rows[0];

      if (order.state === 'PAYMENT_VERIFIED' || order.state === 'ACQUISITION_COMPLETED') {
        const err = new Error('Order is already approved (Concurrent approval blocked)');
        err.status = 409;
        throw err;
      }
```

---

### Area G: Settlement, Accounting, dan Refund

#### Bukti G-01: Penguncian Nilai Harga Tunggal dari Snapshot Katalog
- **Path:** `marketplace/server.js`
- **Baris:** 3586, 3593
```javascript
      // 1. Create acquisition (catalogItem.price copied as price_amount)
      await client.query(
        `INSERT INTO acquisitions (acquisition_id, asset_id, buyer_id, price_amount, currency, provider_id, state, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8)`,
        [acqId, asset_id, buyer_id, catalogItem.price, catalogItem.currency, requestedProviderId, targetState, now]
      );

      // 2. Create payment order (catalogItem.price copied as price_snapshot)
      await client.query(
        `INSERT INTO payment_orders (order_id, acquisition_id, payment_config_snapshot, provider_snapshot, price_snapshot, state, payment_method, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [orderId, acqId, bankSnapshot, requestedProviderId, catalogItem.price, targetState, chosenMethod, now]
      );
```
