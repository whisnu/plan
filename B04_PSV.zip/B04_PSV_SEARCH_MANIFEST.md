# B04_PSV_SEARCH_MANIFEST.md
## Manifest Pencarian Sumber Daya Teknis PSV B-04

**Tanggal Pemeriksaan:** 2026-11-10T11:21:00+07:00  
**Commit Acuan:** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`  
**Cakupan Repositori:** `whisnu/nexa`

---

### 1. Daftar Pola Pencarian dan Temuan Positif

| Pola Pencarian / Identifier | Target File / Direktori | Hasil Temuan | Bukti Relevan |
|---|---|---|---|
| `invokeSprint12LicensingAuthority` | `marketplace/server.js` | 3 kemunculan (definisi L172, pemanggilan L3836, ekspor L4570) | Fungsi integrasi HTTP ke Sprint-12 License Daemon. |
| `SPRINT12_LICENSING_AUTHORITY_URL` | `marketplace/server.js` | L173, L175 | Environment variable URL License Daemon. |
| `app.post('/api/acquisitions'` | `marketplace/server.js` | L3428-L3622 | Endpoint tunggal pembuatan order dan akuisisi. |
| `app.post('/api/orders/:id/admin/approve'` | `marketplace/server.js` | L3789-L3884 | Endpoint persetujuan pembayaran admin dan penerbitan entitlement. |
| `withTransaction` | `marketplace/db/store.js` | L89-L103 | Wrapper transaksi PostgreSQL (`BEGIN ... COMMIT / ROLLBACK`). |
| `CREATE TABLE IF NOT EXISTS acquisitions` | `marketplace/db/schema.postgres.sql` | L63-L75 | Definisi skema tabel `acquisitions`. |
| `CREATE TABLE IF NOT EXISTS entitlements` | `marketplace/db/schema.postgres.sql` | L107-L114 | Definisi skema tabel `entitlements`. |
| `CREATE TABLE IF NOT EXISTS payment_orders` | `marketplace/db/schema.postgres.sql` | L77-L85 | Definisi skema tabel `payment_orders`. |
| `SELECT * FROM payment_orders WHERE order_id = $1 FOR UPDATE` | `marketplace/server.js` | L3796, L3893 | Row-level locking untuk konkurensi admin approval/rejection. |
| `proof_digest` | `marketplace/db/schema.postgres.sql` | L90 (`UNIQUE`) | Deduplikasi bukti transfer bank. |

---

### 2. Daftar Perintah dan Pola Pencarian Negatif (Klaim Ketiadaan Fitur)

Setiap klaim ketiadaan didasarkan pada eksekusi pencarian riil dengan pola terarah dan cakupan yang didokumentasikan di bawah ini:

#### Pencarian Negatif 1: Payment Gateway Otomatis / Webhook / Callback
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git "webhook" marketplace/`
  - **Hasil:** `0 matches` (Tidak ditemukan penanganan webhook payment gateway apa pun).
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git "callback" marketplace/`
  - **Hasil:** Hanya ditemukan pemanggilan fungsi internal `store.withTransaction(callback)` pada `marketplace/db/store.js:L89, L94`. Tidak ada URL callback payment gateway.
- **Kesimpulan Scope:** `NOT FOUND IN SEARCHED SCOPE`. Marketplace NEXA tidak memiliki integrasi payment gateway otomatis pihak ketiga (Midtrans, Stripe, Xendit, PayPal, dll.). Sistem beroperasi 100% menggunakan verifikasi transfer manual (`QRIS_MANUAL` dan `BANK_TRANSFER_MANUAL`).

#### Pencarian Negatif 2: Idempotency Key pada Checkout / Acquisitions
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git -E "idempotency|idempotent" marketplace/server.js`
  - **Hasil:** Hanya ditemukan pada alur resumable chunk upload kreator (`server.js:L1996, L2029`).
  - **Hasil pada endpoint checkout (`/api/acquisitions` dan `/api/orders`):** `0 matches`.
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git "Idempotency-Key" marketplace/`
  - **Hasil:** `0 matches`.
- **Kesimpulan Scope:** `NOT FOUND IN SEARCHED SCOPE`. Endpoint pembuatan order `/api/acquisitions` tidak menerima, memeriksa, atau menegakkan header atau token idempotensi.

#### Pencarian Negatif 3: Mekanisme Refund / Pembatalan Lisensi
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git -i "refund" .`
  - **Hasil:** `0 matches` di seluruh repository `whisnu/nexa`.
- **Kesimpulan Scope:** `NOT FOUND IN SEARCHED SCOPE`. Sistem NEXA sama sekali belum memiliki modul, endpoint, skema database, atau alur logika refund (baik partial refund maupun full refund).

#### Pencarian Negatif 4: Representasi Commercial Bundle / Cart / Multi-Item Acquisition
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git -E "bundle_id|parent_acquisition|order_items|checkout_session" marketplace/`
  - **Hasil:** `0 matches`.
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git "checkout-form" marketplace/`
  - **Hasil:** Ditemukan pada `app.js:L21, L126`, `public/js/app.js:L24`, dan `public/index.html:L642`. Namun form tersebut hanya menerima input skalar tunggal `checkout-item-id` (`item.asset_id || item.id`) untuk 1 item individual.
- **Kesimpulan Scope:** `NOT FOUND IN SEARCHED SCOPE`. Tidak ada struktur data, kolom tabel, atau endpoint yang mendukung pembelian multi-item atau komersial bundle secara kolektif.

#### Pencarian Negatif 5: Kolom Diskon, Pajak, Fee, dan Alokasi SSP
- **Command:** `grep -rnI --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=.git -E "discount|tax|fee|proportional|remainder|ssp" marketplace/db/`
  - **Hasil:** `0 matches`.
- **Kesimpulan Scope:** `NOT FOUND IN SEARCHED SCOPE`. Skema database aktif tidak memiliki kolom untuk mencatat diskon, pajak, biaya transaksi, atau rasio alokasi proporsional.
