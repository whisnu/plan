# B04_PSV_SCOPE_LIMITATIONS.md
## Keterbatasan Ruang Lingkup dan Aspek Belum Terverifikasi (PSV B-04)

**Tanggal:** 2026-11-10T11:22:00+07:00  
**Status Evaluasi:** NOT VERIFIED / INSUFFICIENT EVIDENCE

Dokumen ini memetakan aspek-aspek teknis yang tidak dapat dipastikan atau tidak dapat diverifikasi secara penuh semata-mata dari inspeksi source code statis, beserta alasan objektif dan bukti tambahan yang kelak diperlukan.

---

### 1. Perilaku Nyata Layanan Eksternal Sprint-12 License Daemon

| Aspek Belum Terverifikasi | Alasan Keterbatasan | Bukti Tambahan yang Diperlukan |
|---|---|---|
| **Deduplikasi Internal Daemon** | Repositori `whisnu/nexa` hanya bertindak sebagai client HTTP (`invokeSprint12LicensingAuthority`). Kode internal layanan Sprint-12 License Daemon berada di luar repositori atau berjalan sebagai microservice independen. | Source code backend License Daemon atau pengujian end-to-end dengan live mock untuk membuktikan apakah endpoint `/prepare` menolak duplikat request atau menyimpan idempotency log. |
| **Pembersihan Grant Yatim (*Ghost Grants*)** | Jika koneksi HTTP putus saat Marketplace memanggil `/submit`, tidak dapat dibuktikan dari source apakah License Daemon memiliki cron job, garbage collector, atau transaction timeout untuk membatalkan grant yang tidak diklaim oleh client. | Dokumentasi API kontrak SLA dan lifecycle state machine dari Sprint-12 Licensing Authority. |
| **Kapasitas Konkurensi Lisensi** | Tidak ada metrik throughput atau batas konkurensi pemanggilan lisensi jika satu album berisi 10–50 trek dan dipanggil secara paralel/sekuensial. | Hasil stress-test atau beban konkurensi pemanggilan Sprint-12 License Daemon. |

---

### 2. State dan Data pada Live Database Runtime

| Aspek Belum Terverifikasi | Alasan Keterbatasan | Bukti Tambahan yang Diperlukan |
|---|---|---|
| **Kondisi Data Live PostgreSQL** | Pemeriksaan dibatasi pada file skema statis (`schema.postgres.sql` dan `schema.sql`) serta interaksi kode. Instans live database production/staging tidak diakses selama inspeksi (*read-only static restriction*). | Snapshot dump database aktual, riwayat migrasi yang sudah dieksekusi di database production, atau query verifikasi read-only ke instance PostgreSQL staging. |
| **Trigger Database yang Mungkin Ada** | Pada berkas DDL statis tidak ditemukan definisi database trigger atau stored procedure, namun tidak dapat dibuktikan apakah ada database trigger eksternal yang di-inject di luar berkas skema. | Eksekusi `\dft` atau query ke `information_schema.triggers` pada live database. |

---

### 3. Kontrak Transisi Album Komersial Multi-Item (Model B)

| Aspek Belum Terverifikasi | Alasan Keterbatasan | Bukti Tambahan yang Diperlukan |
|---|---|---|
| **Penerimaan Format Payload Multi-Item** | Tidak ditemukan satupun endpoint yang menerima `assets: [id1, id2, ...]` atau `album_id` untuk akuisisi. Seluruh endpoint checkout saat ini berstatus single-item. | Keputusan arsitektur dan perancangan endpoint baru atau revisi payload `POST /api/acquisitions` di Sprint 17. |
| **Mekanisme Korelasi Persisten Bundle** | Di bawah constraint Zero-DDL, tidak ada kolom `bundle_id` atau `parent_acquisition_id`. Bagaimana Marketplace menampilkan riwayat pembelian bundle ("Anda telah membeli Album X") jika setiap lagu tercatat sebagai baris akuisisi terpisah tanpa foreign key ke entitas album? | Spesifikasi teknis data layer dari Data Architect / Architecture Authority mengenai asosiasi metadata katalog vs tabel transaksi. |
