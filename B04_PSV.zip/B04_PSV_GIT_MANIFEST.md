# B04_PSV_GIT_MANIFEST.md
## Baseline Git dan Lingkungan Pemeriksaan PSV B-04

**Tanggal & Waktu Pemeriksaan:** 2026-11-10T11:20:00+07:00  
**Lingkungan:** Linux (Antigravity IDE Agent Environment)  
**Tujuan Mandat:** Preliminary Source Verification (PSV) — Read-Only Source Inspection untuk Blocker B-04 (Marketplace Transaction Workflow untuk Commercial Bundle)

---

### 1. Identifikasi Repository dan Commit

| Parameter | Nilai Aktual | Status Verifikasi |
|---|---|---|
| **Repository Local Path** | `/opt/antigravity/projects/nexa` | VERIFIED |
| **Active Branch** | `main` | VERIFIED via `git branch --show-current` |
| **Commit SHA (HEAD)** | `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956` | VERIFIED via `git rev-parse HEAD` |
| **Remote URL** | `https://github.com/whisnu/nexa.git` | VERIFIED via `git remote -v` |
| **Remote Reference (origin/main)** | `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956` | VERIFIED via `git rev-parse origin/main` |
| **Remote HEAD Symref (`origin/HEAD`)** | `NOT SET` (Ambiguous argument / unset symref) | RECORDED |
| **Parity Local vs Remote** | `100% SYNCHRONIZED` (`HEAD == origin/main`) | VERIFIED |

---

### 2. Status Working Tree Sebelum Pemeriksaan

Output `git status --short`:
```text
?? docs/roadmaps/Nexa_Development_Roadmap_v4_8.md
?? docs/whitepapers/Nexa_White_Paper_v5_6.md
```

**Catatan Integritas Working Tree:**
- Terdapat dua berkas dokumentasi untracked yang sudah ada sebelum inspeksi dimulai (`docs/roadmaps/Nexa_Development_Roadmap_v4_8.md` dan `docs/whitepapers/Nexa_White_Paper_v5_6.md`).
- Tidak ada modifikasi (*unstaged changes*) maupun file staged pada source code produk, test, skema DDL, maupun konfigurasi.
- Selama inspeksi PSV B-04 berlangsung, tidak ada berkas di luar direktori `evidence/` yang diubah, dihapus, atau dibuat (*Zero-Code-Modification Invariant enforced*).

---

### 3. Direktori dan Cakupan Source yang Diperiksa

Pemeriksaan mencakup seluruh modul terkait transaksi, pembayaran, database, dan lisensi pada repositori:
1. `marketplace/server.js` (Express backend, routes, database queries, licensing invocations).
2. `marketplace/db/schema.postgres.sql` (Skema DDL PostgreSQL aktif dan migrasi alter table).
3. `marketplace/db/schema.sql` (Skema DDL SQLite referensi).
4. `marketplace/db/store.js` (Database abstraction layer, connection pool, transaction wrapper `withTransaction`).
5. `marketplace/index.html` (Frontend UI logic, client-side acquisition flow, modal checkout).
6. `marketplace/app.js` & `marketplace/public/js/app.js` (Legacy/public client scripts).
7. `marketplace/tests/exe04_licensing_authority.test.js` (Unit/integration test suite Sprint-12 licensing).
8. `test/marketplace_payment_concurrency_test.js` (Automated concurrency, row-locking, and payment abuse test suite).
9. `test/sprint12_licensing_integration_test.js` (Integration test suite License Daemon).
