# B04_PSV_REPORT.md
# LAPORAN PRELIMINARY SOURCE VERIFICATION (PSV) — BLOCKER B-04
## Verifikasi Fakta Teknis Workflow Transaksi Marketplace untuk Commercial Bundle

**Pemeriksa:** Programmer / Technical Auditor  
**Repository:** `whisnu/nexa`  
**Branch:** `main`  
**Commit Acuan (HEAD):** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`  
**Remote Head (`origin/main`):** `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`  
**Waktu Pemeriksaan:** 2026-11-10T11:23:00+07:00  
**Area Mandat:** PE-02 Handling Album — Blocker B-04 / NC-08 / CONF-03  
**Status PE-02 Implementation:** `NOT AUTHORIZED`  
**Governance Locks:** Sprint 16 `FROZEN`, PE-01 `FROZEN`, Gate A `NOT PASSED`, Gate B `BLOCKED`

---

## 1. Eksekutif Ringkasan

Pemeriksaan sumber primer (*read-only source inspection*) ini dilakukan untuk membuktikan alur kerja aktual transaksi Marketplace saat ini pada commit `fc08a5c7ac6aa1b0e4bcf64dc264666f149e1956`, sebagai fondasi perumusan kontrak teknis Blocker B-04 dan persiapan integrasi keputusan produk PO:
- Model B: 1 kali checkout komersial menghasilkan $N$ independent acquisitions dan $N$ independent entitlements untuk $N$ berkas anggota `.nx`.
- Alokasi nilai transaksi menggunakan *Relative Stand-Alone Selling Price (SSP)* dengan *Largest Remainder Method* (integer arithmetic).

### Temuan Kunci PSV:
1. **Model Transaksi Saat Ini Bersifat Single-Item Murni:**  
   Endpoint pembuatan order `POST /api/acquisitions` (`marketplace/server.js:L3428-L3622`) hanya menerima 1 `asset_id` skalar dan menghasilkan tepat 1 baris `acquisitions`, 1 baris `payment_orders`, dan 1 baris `payment_proofs`. Belum ada kode yang mendukung keranjang belanja multi-item (*cart*), bundle, atau koleksi aset.
2. **Kesesuaian DDL dengan Keputusan Model B:**  
   Tabel `acquisitions` (`schema.postgres.sql#L63-L75`) dan `entitlements` (`#L107-L114`) secara native **100% mendukung** penyimpanan $N$ akuisisi dan $N$ entitlement independen. Skema DDL memiliki constraint `UNIQUE (acquisition_id)` pada tabel `entitlements`, yang secara absolut melarang 1 akuisisi memiliki banyak entitlement (membuktikan bahwa Model A tidak dapat diterapkan tanpa perubahan skema, sedangkan Model B sepenuhnya mematuhi *Zero-DDL*).
3. **Ketiadaan Payment Gateway Otomatis (Webhook/Callback):**  
   Marketplace NEXA saat ini **tidak memiliki payment gateway otomatis** (tidak ada Stripe, Midtrans, Xendit, atau webhook handler). Pembayaran dilakukan melalui transfer manual (`BANK_TRANSFER_MANUAL` atau `QRIS_MANUAL`) dengan unggah bukti biner, yang diverifikasi secara manual oleh Admin melalui `POST /api/orders/:id/admin/approve`.
4. **Batas Transaksi dan Gap 2PC ke License Daemon (Akar Blocker B-04 / CONF-03):**  
   Pada `POST /api/orders/:id/admin/approve` (`server.js:L3794-L3870`), pemanggilan ke Sprint-12 License Daemon (`invokeSprint12LicensingAuthority`) dieksekusi **di tengah transaksi PostgreSQL** saat baris dikunci `SELECT FOR UPDATE`. Panggilan HTTP ini bersifat synchronous non-2PC (3 tahap: `/prepare`, `/sign`, `/submit`). Jika koneksi HTTP gagal atau timeout, DB lokal melakukan rollback, tetapi lisensi yang terlanjur terbit di License Daemon tertinggal sebagai *ghost grant* tanpa kompensasi.
5. **Ketiadaan Idempotency Key pada Checkout:**  
   Tidak ada penegakan header/token `Idempotency-Key` pada endpoint checkout `/api/acquisitions`. ID transaksi dihasilkan secara acak via `crypto.randomBytes` (`server.js:L3485-L3488`). Deduplikasi hanya dilakukan terhadap hash bukti transfer (`proof_digest UNIQUE`), bukan pada request checkout.
6. **Ketiadaan Modul dan Kolom Refund:**  
   Tidak ditemukan fungsi atau endpoint refund (baik partial maupun full) di seluruh codebase. Tabel `acquisitions` hanya menyimpan `price_amount BIGINT`, tanpa kolom diskon, pajak, biaya gateway, atau rasio SSP.

---

## 2. Tabel Temuan Terperinci (Area A s.d. G)

### Format Standar Temuan:
Setiap temuan diberi ID unik, lokasi baris akurat, potongan kode minimum, interpretasi perilaku, dan batas pemeriksaannya.

| Finding ID | Area | Pernyataan Teknis (Klaim) | Status | File Path & Baris | Call Path | Bukti Kode Minimum | Interpretasi & Dampak Perilaku | Batas Pemeriksaan |
|---|---|---|---|---|---|---|---|---|
| **B04-PSV-01** | A | `acquisitions` memetakan 1 asset ke 1 buyer dengan status dan harga tunggal | **VERIFIED** | `marketplace/db/schema.postgres.sql:L63-L75` | DDL statis database | `CREATE TABLE acquisitions (acquisition_id VARCHAR(128) PRIMARY KEY, asset_id VARCHAR(128) NOT NULL, buyer_id VARCHAR(128) NOT NULL, price_amount BIGINT NOT NULL CHECK (price_amount >= 0), state VARCHAR(64) ...);` | Tabel menyimpan data akuisisi individual. Tidak ada kolom `parent_acquisition_id`, `bundle_id`, atau `checkout_id`. | Hanya file DDL statis; data live DB tidak diperiksa. |
| **B04-PSV-02** | A | `entitlements` memiliki constraint `UNIQUE (acquisition_id)` yang memaksakan relasi 1:1 | **VERIFIED** | `marketplace/db/schema.postgres.sql:L107-L110` | DDL statis database | `CREATE TABLE entitlements (entitlement_id VARCHAR(128) PRIMARY KEY, acquisition_id VARCHAR(128) NOT NULL UNIQUE REFERENCES acquisitions(acquisition_id), license_key VARCHAR(255) NOT NULL UNIQUE ...);` | Satu akuisisi hanya dapat memiliki tepat satu entitlement. Menghalangi Model A di bawah Zero-DDL, namun 100% mendukung Model B. | Berlaku pada PostgreSQL dan SQLite (`schema.sql:L65`). |
| **B04-PSV-03** | A | Tidak ada kolom relasi multi-item atau alokasi bundle di DDL | **NOT FOUND IN SEARCHED SCOPE** | `marketplace/db/schema.postgres.sql:L63-L140` | Pemeriksaan skema DDL lengkap | `grep -E "bundle|parent_acq|order_item|discount" schema.postgres.sql` $\rightarrow$ 0 matches | Relasi bundle antar-anggota tidak disimpan secara relasional di database. | Pencarian mencakup seluruh file skema SQL di repo. |
| **B04-PSV-04** | B | Pembuatan order dilakukan dalam 1 transaksi atomik PostgreSQL lokal | **VERIFIED** | `marketplace/server.js:L3581-L3602`, `marketplace/db/store.js:L89-L103` | `POST /api/acquisitions` $\rightarrow$ `store.withTransaction` | `await store.withTransaction(async (client) => { await client.query('INSERT INTO acquisitions ...'); await client.query('INSERT INTO payment_orders ...'); await client.query('INSERT INTO payment_proofs ...'); });` | Jika salah satu query gagal, seluruh baris (acquisitions, orders, proofs) di-rollback secara atomik di database lokal. | Tidak mencakup file bukti yang sudah ditulis ke disk spool sebelumnya. |
| **B04-PSV-05** | B | Panggilan eksternal License Daemon dilakukan di dalam transaksi DB sebelum COMMIT | **VERIFIED** | `marketplace/server.js:L3794, L3836, L3857` | `POST /api/orders/:id/admin/approve` $\rightarrow$ `withTransaction` $\rightarrow$ `invokeSprint12LicensingAuthority` | `await store.withTransaction(async (client) => { ... const licenseKey = await invokeSprint12LicensingAuthority(...); ... await client.query('INSERT INTO entitlements ...'); });` | Row lock dipegang selama panggilan HTTP eksternal (3 HTTP hops). Kegagalan HTTP memicu ROLLBACK PostgreSQL, tetapi meninggalkan grant di daemon (ketiadaan 2PC). | Terbatas pada alur approval admin. |
| **B04-PSV-06** | C | Ketiadaan Idempotency Key pada checkout order | **NOT FOUND IN SEARCHED SCOPE** | `marketplace/server.js:L3428-L3488` | `POST /api/acquisitions` handler | `const acqId = 'ACQ-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex');` | Setiap pemanggilan menghasilkan order ID dan acquisition ID acak baru. Request berulang membuat duplikat order jika tidak terhadang proof hash. | Pencarian pada seluruh route handler di `server.js`. |
| **B04-PSV-07** | C | Deduplikasi request hanya mengandalkan hash bukti bayar (`proof_digest UNIQUE`) | **VERIFIED** | `marketplace/server.js:L3559-L3574`, `marketplace/db/schema.postgres.sql:L90` | `POST /api/acquisitions` $\rightarrow$ `store.getQuery` | `if (finalDigest) { const replayCheck = await store.getQuery('SELECT ... FROM payment_proofs WHERE proof_digest = ? ...'); if (replayCheck) return res.status(403).json({ error: 'ERR_PROOF_REPLAY' }); }` | Mencegah file bukti bayar yang sama digunakan pada order kedua yang sudah selesai. Tidak mencegah duplikasi checkout sebelum pembayaran disetujui. | Uji otomatis membuktikan penolakan 409 (`test/marketplace_payment_concurrency_test.js:L139`). |
| **B04-PSV-08** | D | Metode pembayaran hanya mendukung transfer manual tanpa webhook gateway | **VERIFIED** | `marketplace/server.js:L3442-L3450` | `POST /api/acquisitions` input validation | `const chosenMethod = (payment_method || 'BANK_TRANSFER').toUpperCase(); if (!['QRIS', 'BANK_TRANSFER'].includes(chosenMethod)) return res.status(400)...` | Tidak ada integrasi payment gateway otomatis pihak ketiga (Midtrans/Stripe). Status bayar diverifikasi manual oleh manusia (Admin). | Pencarian "webhook" dan "callback" menghasilkan 0 matches. |
| **B04-PSV-09** | E | Integrasi License Daemon memanggil 3 endpoint REST sekuensial synchronous | **VERIFIED** | `marketplace/server.js:L172-L320` | `invokeSprint12LicensingAuthority` $\rightarrow$ `/prepare`, `/sign`, `/submit` | `await postEndpoint('/prepare', ...); await postEndpoint('/sign', ...); await postEndpoint('/submit', ...);` | Panggilan dilakukan per-aset individual. Timeout ditetapkan 2500ms per request. Tidak ada batching multi-item. | Perilaku internal License Daemon tidak diperiksa (di luar repo). |
| **B04-PSV-10** | E | `acquisition_id` tidak dikirimkan ke License Daemon sebagai idempotency key | **VERIFIED** | `marketplace/server.js:L202-L210` | `invokeSprint12LicensingAuthority` prepare payload | `const preparePayload = JSON.stringify({ asset_id: canonicalAssetId, licensee_subject_id: buyerId, licensor_subject_id: licensorSubject, rights: ['USAGE_RIGHT_EXECUTE', 'PLAY'], ... });` | Parameter `acqId` yang diterima fungsi diabaikan; tidak ada ID transaksi yang mengikat lisensi di daemon, memicu risiko lisensi duplikat jika di-retry. | Terbukti dari inspeksi baris 202-210. |
| **B04-PSV-11** | F | Konkurensi approval ditangkal oleh `SELECT FOR UPDATE` + state check | **VERIFIED** | `marketplace/server.js:L3796-L3808`, `test/marketplace_payment_concurrency_test.js:L145-L152` | `POST /api/orders/:id/admin/approve` | `const orderRes = await client.query('SELECT * FROM payment_orders WHERE order_id = $1 FOR UPDATE', [orderId]); if (order.state === 'PAYMENT_VERIFIED') throw new Error('Order is already approved');` | Mencegah double-approval: approval kedua ditolak dengan HTTP 409 Conflict. Telah teruji di test suite concurrency. | Berlaku di lingkungan PostgreSQL. |
| **B04-PSV-12** | G | `price_amount` disalin langsung dari `catalog_snapshots.price` tanpa alokasi diskon | **VERIFIED** | `marketplace/server.js:L3586, L3593` | `POST /api/acquisitions` insert query | `VALUES ($1, $2, $3, catalogItem.price, catalogItem.currency, ...)` | Nilai yang disimpan adalah harga katalog item tunggal. Tidak ada logika alokasi proporsional atau penyimpanan diskon bundle. | Berlaku untuk single asset checkout saat ini. |
| **B04-PSV-13** | G | Mekanisme refund dan kolom akuntansi terpisah tidak tersedia | **NOT FOUND IN SEARCHED SCOPE** | Seluruh repositori `whisnu/nexa` | Pencarian global regex `refund` | `grep -rnI "refund" .` $\rightarrow$ 0 matches | Tidak ada API, model, maupun logika refund parsial maupun pembatalan lisensi. | Berlaku di seluruh ruang lingkup kode. |

---

## 3. Evaluasi Skenario Kegagalan (Area F)

Tabel berikut membuktikan perilaku aktual sistem terhadap 8 skenario kegagalan:

| No | Skenario Kegagalan | Titik Kegagalan | Data Tersimpan di DB | Side Effect Eksternal | Status Tercatat di Sistem | Mekanisme Recovery Aktual | Bagian yang Belum Dapat Dipastikan |
|---|---|---|---|---|---|---|---|
| 1 | **Payment berhasil (dana masuk), penulisan acquisition gagal** | Database down saat `POST /api/acquisitions` | 0 baris tersimpan (karena transaksi DB gagal) | Uang konsumen sudah tertransfer ke rekening bank / QRIS | Tidak tercatat sama sekali di sistem Marketplace | **Manual Offline:** Konsumen harus melapor ke Admin membawa bukti transfer fisik/screenshot. | Tidak ada automated payment reconciliation. |
| 2 | **Acquisition berhasil tersimpan, entitlement gagal** | Error di `POST /api/orders/:id/admin/approve` (misal License Daemon timeout) | Status order tetap `PAYMENT_PENDING_VERIFICATION` (perubahan DB di-rollback) | Jika `/submit` di daemon terlanjur berhasil, lisensi terbit di daemon tanpa ada entri di DB lokal | `PAYMENT_PENDING_VERIFICATION` | **Admin Retry:** Admin dapat mengklik Approve kembali setelah koneksi daemon pulih. | Apakah License Daemon membatalkan lisensi yang tidak pernah di-commit client (*unverified*). |
| 3 | **Sebagian anggota berhasil, anggota lain gagal (Multi-member)** | Saat memproses anggota ke-$k$ dalam loop Album | Belum ada kode multi-member (`NOT IMPLEMENTED`) | Belum ada kode multi-member | N/A | **TIDAK TERSEDIA.** Inilah gap fundamental Blocker B-04 / CONF-03 yang harus dirumuskan kontraknya. | Bagaimana License Daemon menangani batch rollback multi-lisensi. |
| 4 | **License Daemon Timeout (>2500ms)** | `sendHttpRequest` melempar timeout pada baris 230 | Transaksi PostgreSQL di-rollback penuh (`ROLLBACK`) | Potensi *orphaned grant* di License Daemon | Order tetap `PAYMENT_PENDING_VERIFICATION`, melempar HTTP 502 | Admin mencoba Approve ulang. | Apakah pemanggilan ulang menghasilkan grant duplikat di daemon (diduga kuat YA karena `acqId` tidak dikirim). |
| 5 | **Callback / Approval ganda (Concurrent Request)** | Dua admin mengklik approve secara bersamaan | Transaksi 1 berhasil commit; transaksi 2 gagal terlempar error 409 | Hanya 1 lisensi yang dipanggil ke daemon | Tepat 1 `PAYMENT_VERIFIED` dan 1 entitlement tercatat | **Otomatis Fail-Closed:** Terlindungi oleh `SELECT FOR UPDATE` dan guard state (`test/marketplace_payment_concurrency_test.js`). | Penuh terverifikasi pada PostgreSQL. |
| 6 | **Client mengirim ulang checkout (Retry Client)** | Client mengklik tombol "Confirm" 2 kali | Jika tanpa bukti transfer unik, tercipta 2 order berbeda (`ORD-1`, `ORD-2`) | Tidak ada (belum dibayar) | Tercipta 2 baris `acquisitions` status pending | Tidak ada idempotency guard; salah satu order harus dibatalkan via `POST /api/acquisitions/:id/cancel`. | Ketiadaan header `Idempotency-Key`. |
| 7 | **Server Restart di tengah transaksi** | Node.js mati saat query DB atau HTTP daemon berjalan | PostgreSQL otomatis me-rollback transaksi terbuka | Permintaan HTTP ke daemon mungkin terlanjur terkirim | State tetap seperti sebelum transaksi dimulai | Server start kembali; order tetap pada state sebelumnya. | Lisensi yatim di daemon jika mati saat tahap submit. |
| 8 | **Retry dilakukan setelah sebagian side effect berhasil** | Admin retry approve setelah timeout di tahap `/submit` | Transaksi DB lokal baru dieksekusi dari awal | Daemon menerima panggilan baru dan menerbitkan lisensi kedua | 1 entitlement tercatat di DB lokal, tetapi 2 lisensi aktif di daemon | Tidak ada deduplikasi di sisi Marketplace. | Apakah daemon mendeteksi duplikat `asset_id` + `buyer_id`. |

---

## 4. Klasifikasi Hasil PSV

### Kategori A: VERIFIED FACTS (Fakta Terbukti secara Primer)
1. **Model Transaksi Saat Ini Adalah Single-Item Murni:**  
   `POST /api/acquisitions` hanya memproses satu `asset_id` per request (`server.js:L3428-L3622`).
2. **Kesesuaian DDL dengan Keputusan Model B:**  
   Tabel `acquisitions` dan `entitlements` memiliki struktur flat 1:1 (`entitlements.acquisition_id UNIQUE`), yang siap menampung $N$ baris independent acquisitions untuk $N$ anggota `.nx` tanpa melanggar constraint skema DDL yang ada.
3. **Ketiadaan Payment Gateway Pihak Ketiga:**  
   Tidak ada integrasi Stripe/Midtrans/Xendit maupun webhook listener. Seluruh verifikasi pembayaran bergantung pada bukti transfer bank/QRIS manual yang diapprove admin.
4. **Ketiadaan Idempotency Key pada Checkout:**  
   Identifier dihasilkan via `crypto.randomBytes(4)`. Tidak ada tabel idempotensi atau validasi header request.
5. **Ketiadaan 2PC ke License Daemon:**  
   `invokeSprint12LicensingAuthority` dipanggil synchronous di dalam blok `withTransaction` PostgreSQL tanpa kompensasi terdistribusi atau 2PC.
6. **Ketiadaan Modul dan Kolom Refund:**  
   Nol kemunculan kata "refund" di seluruh codebase produk.

---

### Kategori B: NOT VERIFIED / INSUFFICIENT EVIDENCE (Keterbatasan)
1. **Perilaku Internal License Daemon:**  
   Tidak dapat dipastikan dari source code repositori ini apakah daemon Sprint-12 memiliki deduplikasi internal, TTL grant otomatis, atau mekanisme idempotensi, karena kode daemon tidak berada di repositori `whisnu/nexa`.
2. **Kondisi Live Database Production/Staging:**  
   Inspeksi dilakukan secara statis terhadap berkas DDL SQL dan kode aplikasi; instans live PostgreSQL tidak diakses (*read-only static source inspection*).

---

### Kategori C: IMPLEMENTATION GAPS TERHADAP TARGET MODEL B & SSP
Berikut daftar gap implementasi aktual dibandingkan dengan keputusan normatif PO (**Model B + Alokasi Proporsional SSP + Largest Remainder Method**):

| Aspek Target PO | Kondisi Aktual Terbukti di Kode | Implementation Gap |
|---|---|---|
| **Commercial Bundle Checkout (1 Checkout $\rightarrow N$ Acquisitions)** | Endpoint hanya menerima 1 `asset_id` skalar string. | Dibutuhkan endpoint atau perombakan payload `POST /api/acquisitions` yang menerima array $N$ `asset_id` dan menerbitkan $N$ baris `acquisitions` dalam 1 transaksi. |
| **Independent Entitlements ($N$ Lisensi)** | Panggilan `invokeSprint12LicensingAuthority` hanya dilakukan 1 kali untuk 1 aset. | Diperlukan mekanisme pemanggilan lisensi untuk $N$ aset anggota, disertai penanganan kegagalan parsial (*partial failure compensation*). |
| **Alokasi Nilai Transaksi berbasis SSP** | `price_amount` langsung disalin dari harga katalog aset tunggal (`catalogItem.price`). | Belum ada logika perhitungan rasio bobot katalog $\left(\frac{\text{catalog\_price}_i}{\sum \text{catalog\_price}}\right) \times \text{bundle\_paid}$. |
| **Largest Remainder Method (Integer Arithmetic)** | Tidak ada operasi pembagian atau alokasi sisa pembulatan. | Belum ada implementasi algoritma Hamilton/Hare-Niemeyer untuk mendistribusikan sisa integer modulo ke aset berbobot tertinggi / indeks awal. |
| **Idempotency & Replay Protection** | Tidak ada `Idempotency-Key` pada checkout; hanya ada `proof_digest UNIQUE`. | Diperlukan penegakan idempotency token agar checkout bundle tidak diproses berulang kali. |
| **Korelasi Persisten Bundle di Bawah Zero-DDL** | Tidak ada kolom `bundle_id` atau `parent_acquisition_id` pada tabel `acquisitions`. | Diperlukan konvensi penyimpanan korelasi (misal melalui snapshot metadata, prefix acquisition ID deterministik, atau event log) yang tidak melanggar Zero-DDL. |

---

## 5. Kesimpulan dan Rekomendasi untuk Architecture Authority

1. **PSV B-04 Selesai:**  
   Seluruh fakta implementasi transaksi Marketplace, skema DDL, batasan transaksi, ketiadaan gateway otomatis, alur License Daemon, skenario kegagalan, dan ketiadaan refund telah berhasil diverifikasi dengan bukti primer berbasis path dan nomor baris.
2. **Keputusan Model B PO Tervalidasi Kuat oleh Skema DDL:**  
   Pilihan PO untuk menggunakan **Model B** terbukti sangat tepat karena skema DDL `entitlements` yang memiliki constraint `UNIQUE (acquisition_id)` secara alami menolak Model A, namun secara sempurna mengakomodasi Model B.
3. **Mandat Arsitektur untuk Sprint 17 (Bukan Otorisasi Koding):**  
   Laporan ini mengidentifikasi secara presisi gap yang harus dirumuskan dalam kontrak desain teknis B-04 oleh Architecture Authority di PLAN:
   - Pola transaksi batch checkout di bawah batasan Zero-DDL.
   - Idempotency boundary & settlement reconciliation untuk pemanggilan License Daemon tanpa 2PC.
   - Algoritma deterministik SSP & Largest Remainder Method berbasis integer arithmetic.

**Status Tata Kelola:**
- Sprint 16: `CLOSED / FROZEN`
- PE-01: `CLOSED / FROZEN`
- Sprint 17: `NOT STARTED`
- Gate A: `NOT PASSED`
- Gate B: `BLOCKED`
- PE-02 Implementation: `NOT AUTHORIZED`
